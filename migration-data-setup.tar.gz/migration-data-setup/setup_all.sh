#!/usr/bin/env bash
#
# setup_all.sh — 一键初始化所有基础设施（Athena + OpenSearch + mem0）
#
# Usage:
#   bash setup_all.sh
#
set -euo pipefail

export HOME="${HOME:-/home/ubuntu}"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "╔══════════════════════════════════════════════╗"
echo "║    CFO 智能助手 — 基础设施一键初始化          ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

# ── Dependencies ──
echo "🔍 Checking dependencies..."
if ! command -v aws >/dev/null 2>&1; then
  echo "  📦 Installing AWS CLI v2..."
  cd /tmp
  curl -fsSL "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o awscliv2.zip
  unzip -qo awscliv2.zip
  sudo ./aws/install --update 2>/dev/null || sudo ./aws/install
  rm -rf aws awscliv2.zip
  echo "  ✅ AWS CLI installed: $(aws --version)"
  cd "$SCRIPT_DIR"
else
  echo "  ✅ AWS CLI: $(aws --version 2>&1 | head -1)"
fi
echo ""

# ── Step 1: Athena ──
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Step 1/3: Athena"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
bash "$SCRIPT_DIR/setup_athena.sh"
echo ""

# ── Step 2: OpenSearch ──
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Step 2/3: OpenSearch"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
bash "$SCRIPT_DIR/setup_opensearch.sh"
echo ""

# ── Step 3: mem0 ──
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Step 3/3: mem0"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
bash "$SCRIPT_DIR/setup_mem0.sh"
echo ""

# ── Done ──
echo "╔══════════════════════════════════════════════╗"
echo "║             ✅ 全部完成！                     ║"
echo "╚══════════════════════════════════════════════╝"
echo ""
echo "验证："
echo "  Athena:     aws athena list-databases --catalog-name AwsDataCatalog --region us-east-1"
echo "  OpenSearch: curl -s localhost:9200/budget-knowledge/_count"
echo "  mem0:       curl -s localhost:8765/health"
