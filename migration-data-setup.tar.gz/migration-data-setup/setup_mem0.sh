#!/usr/bin/env bash
#
# setup_mem0.sh — Deploy mem0 service + restore vector memories
#
# 桶命名: openclaw-memory-vectors-{account_id}  (S3 Vectors bucket)
# Region: us-east-1 (固定)
#
# 在 agent 部署之前运行。包含：
#   1. 创建 S3 Vectors bucket
#   2. 部署 mem0 HTTP 服务（systemd user unit）
#   3. 恢复向量记忆数据
#
# Usage:
#   bash setup_mem0.sh [--source-dir /path/to/service-source] [--vectors-dir /path/to/vectors]
#
set -euo pipefail

REGION="us-east-1"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SOURCE_DIR="$SCRIPT_DIR/mem0-service-source"
VECTORS_DIR="$SCRIPT_DIR/mem0-vectors"
MEM0_DIR="$HOME/memory-s3vectors/mem0"

while [[ $# -gt 0 ]]; do
  case $1 in
    --source-dir) SOURCE_DIR="$2"; shift 2 ;;
    --vectors-dir) VECTORS_DIR="$2"; shift 2 ;;
    -h|--help)
      echo "Usage: bash $0 [--source-dir DIR] [--vectors-dir DIR]"
      exit 0 ;;
    *) echo "Unknown arg: $1"; exit 1 ;;
  esac
done

ACCOUNT_ID=$(aws sts get-caller-identity --region "$REGION" --query Account --output text)
VECTOR_BUCKET="openclaw-memory-vectors-${ACCOUNT_ID}"

# Region → Bedrock LLM model mapping
case "$REGION" in
  ap-northeast-1) LLM_MODEL="jp.anthropic.claude-haiku-4-5-20251001-v1:0" ;;
  us-east-1|us-west-2) LLM_MODEL="us.anthropic.claude-3-haiku-20240307-v1:0" ;;
  eu-west-1|eu-central-1) LLM_MODEL="eu.anthropic.claude-3-haiku-20240307-v1:0" ;;
  *) LLM_MODEL="anthropic.claude-3-haiku-20240307-v1:0" ;;
esac

echo "╔══════════════════════════════════════════════╗"
echo "║         mem0 Environment Setup               ║"
echo "╚══════════════════════════════════════════════╝"
echo ""
echo "  Account:   $ACCOUNT_ID"
echo "  Region:    $REGION"
echo "  Bucket:    $VECTOR_BUCKET"
echo "  LLM:       $LLM_MODEL"
echo "  Source:    $SOURCE_DIR"
echo "  Vectors:   $VECTORS_DIR"
echo ""

# ──────────────────────────────────────────────────
# Part 1: S3 Vectors bucket
# ──────────────────────────────────────────────────

echo "🪣 Checking S3 Vectors bucket..."
if aws s3vectors get-vector-bucket --vector-bucket-name "$VECTOR_BUCKET" --region "$REGION" >/dev/null 2>&1; then
  echo "  ✅ Bucket already exists: $VECTOR_BUCKET"
else
  echo "  📦 Creating: $VECTOR_BUCKET"
  aws s3vectors create-vector-bucket --vector-bucket-name "$VECTOR_BUCKET" --region "$REGION"
  echo "  ✅ Created"
fi

# ──────────────────────────────────────────────────
# Part 2: Deploy service
# ──────────────────────────────────────────────────

echo ""
echo "📦 Deploying mem0 service..."

if [[ ! -f "$SOURCE_DIR/service.py" ]]; then
  echo "❌ service.py not found in $SOURCE_DIR"
  exit 1
fi

mkdir -p "$MEM0_DIR"
chown -R ubuntu:ubuntu "$HOME/memory-s3vectors"
cp "$SOURCE_DIR/service.py" "$MEM0_DIR/"
cp "$SOURCE_DIR/requirements.txt" "$MEM0_DIR/"
echo "  ✅ Files deployed to $MEM0_DIR"

# Adapt for region + bucket
sed -i "s|aws_region: str = \"[^\"]*\"|aws_region: str = \"$REGION\"|" "$MEM0_DIR/service.py"
sed -i "s|vector_bucket_name: str = \"[^\"]*\"|vector_bucket_name: str = \"$VECTOR_BUCKET\"|" "$MEM0_DIR/service.py"
sed -i "s|llm_model: str = \"[^\"]*\"|llm_model: str = \"$LLM_MODEL\"|" "$MEM0_DIR/service.py"
echo "  ✅ Configured: region=$REGION, bucket=$VECTOR_BUCKET, llm=$LLM_MODEL"

# Install deps
echo "  📦 Installing Python dependencies..."
pip install -q --break-system-packages --ignore-installed typing_extensions --upgrade -r "$MEM0_DIR/requirements.txt" 2>&1 | tail -3 || \
pip install -q --ignore-installed typing_extensions --upgrade -r "$MEM0_DIR/requirements.txt" 2>&1 | tail -3
echo "  ✅ Dependencies installed"

# ──────────────────────────────────────────────────
# Part 3: Systemd service
# ──────────────────────────────────────────────────

echo ""
echo "🔧 Setting up systemd service..."

# Ensure user lingering is enabled (allows user services without active login session)
if ! loginctl show-user "$(whoami)" --property=Linger 2>/dev/null | grep -q "yes"; then
  sudo loginctl enable-linger "$(whoami)" 2>/dev/null || true
  echo "  ✅ Linger enabled for $(whoami)"
fi

# Ensure XDG_RUNTIME_DIR and DBUS_SESSION_BUS_ADDRESS are set
export XDG_RUNTIME_DIR="${XDG_RUNTIME_DIR:-/run/user/$(id -u)}"
if [[ ! -d "$XDG_RUNTIME_DIR" ]]; then
  sudo mkdir -p "$XDG_RUNTIME_DIR"
  sudo chown "$(whoami):$(id -gn)" "$XDG_RUNTIME_DIR"
  sudo chmod 700 "$XDG_RUNTIME_DIR"
fi
export DBUS_SESSION_BUS_ADDRESS="${DBUS_SESSION_BUS_ADDRESS:-unix:path=$XDG_RUNTIME_DIR/bus}"

UNIT_DIR="$HOME/.config/systemd/user"
mkdir -p "$UNIT_DIR"

cat > "$UNIT_DIR/mem0-service.service" << EOF
[Unit]
Description=Mem0 Memory Service (S3 Vectors + Bedrock)
After=network.target

[Service]
Type=simple
WorkingDirectory=$MEM0_DIR
Environment=AWS_REGION=$REGION
ExecStart=/usr/bin/python3 -m uvicorn service:app --host 127.0.0.1 --port 8765 --log-level info
Restart=on-failure
RestartSec=5

[Install]
WantedBy=default.target
EOF

systemctl --user daemon-reload
systemctl --user enable mem0-service 2>/dev/null || true

# Start or restart
if curl -s http://127.0.0.1:8765/health >/dev/null 2>&1; then
  echo "  🔄 mem0 already running, restarting with new config..."
  systemctl --user restart mem0-service
else
  systemctl --user start mem0-service
fi

echo "  ⏳ Waiting for service..."
MEM0_READY=false
for i in $(seq 1 15); do
  if curl -s http://127.0.0.1:8765/health >/dev/null 2>&1; then
    echo "  ✅ mem0 is healthy!"
    curl -s http://127.0.0.1:8765/health
    echo ""
    MEM0_READY=true
    break
  fi
  sleep 1
done

if [[ "$MEM0_READY" == "false" ]]; then
  echo "  ❌ mem0 failed to start"
  echo "  Check: journalctl --user -u mem0-service --no-pager -n 20"
  exit 1
fi

# ──────────────────────────────────────────────────
# Part 4: Restore vector memories
# ──────────────────────────────────────────────────

echo ""

VECTOR_FILES=$(find "$VECTORS_DIR" -name "*-vectors.json" 2>/dev/null | sort)
if [[ -z "$VECTOR_FILES" ]]; then
  echo "⚠️  No *-vectors.json files found in $VECTORS_DIR — skipping data restore"
  echo ""
  echo "✅ mem0 setup complete (no data restored)."
  exit 0
fi

VECTOR_COUNT=$(echo "$VECTOR_FILES" | wc -l)
echo "📥 Restoring mem0 vector memories ($VECTOR_COUNT files)..."

# Ensure boto3 is available (should be from requirements.txt)
if ! python3 -c "import boto3" 2>/dev/null; then
  pip install -q --break-system-packages boto3 2>&1 | tail -1 || pip install -q boto3 2>&1 | tail -1
fi

python3 - "$VECTOR_BUCKET" "$REGION" $VECTOR_FILES << 'RESTORE_SCRIPT'
import json, sys, glob, os

bucket = sys.argv[1]
region = sys.argv[2]
files = sys.argv[3:]

import boto3
client = boto3.client("s3vectors", region_name=region)

total_written = 0

for filepath in files:
    with open(filepath) as f:
        data = json.load(f)

    if data.get("format") != "s3vectors-full":
        print(f"  ⚠️  {os.path.basename(filepath)}: unknown format, skipping")
        continue

    index_name = data["index_name"]
    config = data.get("index_config", {})
    vectors = data.get("vectors", [])

    if not vectors:
        print(f"  ⏭️  {index_name}: empty, skipping")
        continue

    # Check if index already has vectors
    try:
        idx_info = client.get_index(vectorBucketName=bucket, indexName=index_name)
        # Index exists — check if it already has data by listing a few
        existing = client.list_vectors(vectorBucketName=bucket, indexName=index_name, maxResults=1)
        if existing.get("vectors", []):
            print(f"  ✅ {index_name}: already has data ({len(vectors)} expected), skipping")
            continue
    except client.exceptions.NotFoundException:
        # Create index
        client.create_index(
            vectorBucketName=bucket,
            indexName=index_name,
            dataType=config.get("dataType", "float32"),
            dimension=config.get("dimension", 1024),
            distanceMetric=config.get("distanceMetric", "cosine"),
        )
        print(f"  📦 {index_name}: index created")

    # Batch write
    batch_size = 50
    written = 0
    for i in range(0, len(vectors), batch_size):
        batch = vectors[i:i+batch_size]
        entries = []
        for v in batch:
            entry = {"key": v["key"], "metadata": v.get("metadata", {})}
            vec = v.get("vector")
            if vec:
                dt = config.get("dataType", "float32")
                entry["data"] = {dt: vec}
            entries.append(entry)

        try:
            client.put_vectors(vectorBucketName=bucket, indexName=index_name, vectors=entries)
            written += len(batch)
        except Exception as e:
            print(f"  ❌ {index_name}: batch error at {i}: {e}")

    print(f"  ✅ {index_name}: {written}/{len(vectors)} vectors")
    total_written += written

print(f"\n  Total: {total_written} vectors restored")
RESTORE_SCRIPT

echo ""
echo "✅ mem0 setup complete!"
echo "   Service:  http://127.0.0.1:8765"
echo "   Bucket:   $VECTOR_BUCKET"
echo "   Region:   $REGION"
