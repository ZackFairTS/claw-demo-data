#!/usr/bin/env bash
#
# setup_athena.sh — Initialize Athena: S3 bucket + parquet upload + Glue DB/tables/views
#
# 桶命名: openclaw-analytics-us-east-1-{account_id}
# Region: us-east-1 (固定)
# 数据目录: 脚本同级 data/ 下的 *.parquet 文件
#
# 在 agent 部署之前运行。所有 agent skill 按此命名规则引用。
#
# Usage:
#   bash setup_athena.sh [--data-dir /path/to/parquet]
#

set -euo pipefail

REGION="us-east-1"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
DATA_DIR="$SCRIPT_DIR/data"

while [[ $# -gt 0 ]]; do
  case $1 in
    --data-dir) DATA_DIR="$2"; shift 2 ;;
    -h|--help) echo "Usage: bash $0 [--data-dir /path/to/parquet]"; exit 0 ;;
    *) echo "Unknown arg: $1"; exit 1 ;;
  esac
done

# ── Get account ID ──
ACCOUNT_ID=$(aws sts get-caller-identity --region "$REGION" --query Account --output text)
BUCKET="openclaw-analytics-${REGION}-${ACCOUNT_ID}"

echo "╔══════════════════════════════════════════════╗"
echo "║         Athena Environment Setup             ║"
echo "╚══════════════════════════════════════════════╝"
echo ""
echo "  Account:  $ACCOUNT_ID"
echo "  Region:   $REGION"
echo "  Bucket:   $BUCKET"
echo "  Data dir: $DATA_DIR"
echo ""

# ── Validate data dir ──
if [[ ! -d "$DATA_DIR" ]]; then
  echo "❌ Data directory not found: $DATA_DIR"
  exit 1
fi
PARQUET_COUNT=$(find "$DATA_DIR" -name "*.parquet" | wc -l)
if [[ "$PARQUET_COUNT" -eq 0 ]]; then
  echo "❌ No .parquet files found in $DATA_DIR"
  exit 1
fi
echo "  Found $PARQUET_COUNT parquet files"
echo ""

# ── Create bucket if not exists ──
if aws s3api head-bucket --bucket "$BUCKET" 2>/dev/null; then
  echo "🪣 Bucket already exists: $BUCKET"
else
  echo "🪣 Creating bucket: $BUCKET"
  # us-east-1 does not use LocationConstraint
  aws s3api create-bucket --bucket "$BUCKET" --region "$REGION"
  aws s3api put-bucket-encryption --bucket "$BUCKET" \
    --server-side-encryption-configuration \
    '{"Rules":[{"ApplyServerSideEncryptionByDefault":{"SSEAlgorithm":"AES256"}}]}'
  aws s3api put-bucket-versioning --bucket "$BUCKET" \
    --versioning-configuration Status=Enabled
  echo "  ✅ Bucket created (encryption + versioning)"
fi

# ── Upload data files ──
echo ""
echo "📤 Uploading parquet data..."
for f in "$DATA_DIR"/*.parquet; do
  TABLE=$(basename "$f" .parquet)
  aws s3 cp "$f" "s3://$BUCKET/budget-demo/$TABLE/$TABLE.parquet" --region "$REGION" --quiet
  echo "  ✅ $TABLE"
done

# ── Athena helper ──
OUTPUT="s3://$BUCKET/athena-results/"

run_athena() {
  local sql="$1"
  local label="$2"
  local qid
  qid=$(aws athena start-query-execution \
    --query-string "$sql" \
    --query-execution-context Database=openclaw_analytics \
    --result-configuration OutputLocation="$OUTPUT" \
    --region "$REGION" --output text --query QueryExecutionId 2>/dev/null)

  local state=""
  while true; do
    state=$(aws athena get-query-execution --query-execution-id "$qid" --region "$REGION" \
      --query 'QueryExecution.Status.State' --output text 2>/dev/null)
    [[ "$state" == "RUNNING" || "$state" == "QUEUED" ]] || break
    sleep 1
  done

  if [[ "$state" == "SUCCEEDED" ]]; then
    echo "  ✅ $label"
  else
    local reason
    reason=$(aws athena get-query-execution --query-execution-id "$qid" --region "$REGION" \
      --query 'QueryExecution.Status.StateChangeReason' --output text 2>/dev/null)
    echo "  ❌ $label ($state): $reason"
    return 1
  fi
}

# ── Create database ──
echo ""
echo "📦 Creating database..."
run_athena "CREATE DATABASE IF NOT EXISTS openclaw_analytics" "openclaw_analytics"

# ── Create tables ──
echo ""
echo "📋 Creating tables..."

run_athena "
CREATE EXTERNAL TABLE IF NOT EXISTS openclaw_analytics.budget_summary (
  quarter string, department string, department_en string,
  budget double, actual double, variance double, variance_rate double
) STORED AS PARQUET
LOCATION 's3://$BUCKET/budget-demo/budget_summary/'
" "budget_summary"

run_athena "
CREATE EXTERNAL TABLE IF NOT EXISTS openclaw_analytics.budget_actuals (
  quarter string, department string, category string, month string,
  budget double, actual double, variance double
) STORED AS PARQUET
LOCATION 's3://$BUCKET/budget-demo/budget_actuals/'
" "budget_actuals"

run_athena "
CREATE EXTERNAL TABLE IF NOT EXISTS openclaw_analytics.budget_plans (
  quarter string, department string, category string, month string,
  planned_budget double
) STORED AS PARQUET
LOCATION 's3://$BUCKET/budget-demo/budget_plans/'
" "budget_plans"

run_athena "
CREATE EXTERNAL TABLE IF NOT EXISTS openclaw_analytics.department_info (
  department string, head string, title string, headcount int,
  key_projects string, key_expenses string,
  q3_budget bigint, q3_actual bigint, q3_variance bigint,
  q3_variance_rate double, main_reasons string
) STORED AS PARQUET
LOCATION 's3://$BUCKET/budget-demo/department_info/'
" "department_info"

# ── Create views ──
echo ""
echo "📊 Creating views..."

run_athena "
CREATE OR REPLACE VIEW openclaw_analytics.v_budget_variance AS
SELECT quarter, department, category, month, budget, actual, variance,
  CASE WHEN budget > 0 THEN ROUND((variance / budget) * 100, 2) ELSE 0 END AS variance_pct
FROM openclaw_analytics.budget_actuals
" "v_budget_variance"

run_athena "
CREATE OR REPLACE VIEW openclaw_analytics.v_cost_breakdown AS
SELECT quarter, department, category,
  SUM(budget) AS total_budget, SUM(actual) AS total_actual, SUM(variance) AS total_variance
FROM openclaw_analytics.budget_actuals
GROUP BY quarter, department, category
" "v_cost_breakdown"

run_athena "
CREATE OR REPLACE VIEW openclaw_analytics.v_department_trend AS
SELECT quarter, department,
  SUM(budget) AS total_budget, SUM(actual) AS total_actual, SUM(variance) AS total_variance,
  CASE WHEN SUM(budget) > 0 THEN ROUND((SUM(variance) / SUM(budget)) * 100, 2) ELSE 0 END AS variance_rate
FROM openclaw_analytics.budget_actuals
GROUP BY quarter, department
" "v_department_trend"

run_athena "
CREATE OR REPLACE VIEW openclaw_analytics.v_overrun_alert AS
SELECT quarter, department, budget, actual, variance, variance_rate
FROM openclaw_analytics.budget_summary
WHERE variance_rate > 0.1
" "v_overrun_alert"

# ── Verify ──
echo ""
echo "🔍 Verifying..."
run_athena "SELECT department, variance_rate FROM openclaw_analytics.budget_summary WHERE quarter = 'Q3' ORDER BY variance_rate DESC LIMIT 3" "Test query"

echo ""
echo "✅ Athena setup complete!"
echo "   Database: openclaw_analytics"
echo "   Bucket:   $BUCKET"
echo "   Region:   $REGION"
echo "   Tables:   budget_summary, budget_actuals, budget_plans, department_info"
echo "   Views:    v_budget_variance, v_cost_breakdown, v_department_trend, v_overrun_alert"
