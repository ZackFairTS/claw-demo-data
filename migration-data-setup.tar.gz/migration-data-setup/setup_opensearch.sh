#!/usr/bin/env bash
#
# setup_opensearch.sh — Install OpenSearch + restore budget-knowledge index
#
# 在 agent 部署之前运行。包含：
#   1. 确保 OpenSearch 在 localhost:9200 运行（Docker）
#   2. 从 JSON 导出文件恢复 budget-knowledge 索引
#
# Usage:
#   bash setup_opensearch.sh [--version 2.18.0] [--memory 512m] [--data-file /path/to/export.json]
#
set -euo pipefail

OS_VERSION="${OS_VERSION:-2.18.0}"
OS_MEMORY="${OS_MEMORY:-512m}"
OS_CONTAINER="opensearch"
OS_PORT=9200
MAX_WAIT=60

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
DATA_FILE="$SCRIPT_DIR/opensearch-data/opensearch-budget-knowledge.json"

while [[ $# -gt 0 ]]; do
  case $1 in
    --version) OS_VERSION="$2"; shift 2 ;;
    --memory) OS_MEMORY="$2"; shift 2 ;;
    --data-file) DATA_FILE="$2"; shift 2 ;;
    -h|--help)
      echo "Usage: bash $0 [--version VERSION] [--memory HEAP] [--data-file FILE]"
      exit 0 ;;
    *) echo "Unknown arg: $1"; exit 1 ;;
  esac
done

echo "╔══════════════════════════════════════════════╗"
echo "║       OpenSearch Environment Setup           ║"
echo "╚══════════════════════════════════════════════╝"
echo ""
echo "  Version:   $OS_VERSION"
echo "  Heap:      $OS_MEMORY"
echo "  Data file: $DATA_FILE"
echo ""

# ──────────────────────────────────────────────────
# Part 1: Ensure OpenSearch is running
# ──────────────────────────────────────────────────

wait_for_opensearch() {
  local max=$1
  echo "  ⏳ Waiting for OpenSearch (up to ${max}s)..."
  for i in $(seq 1 "$max"); do
    if curl -s "localhost:$OS_PORT" >/dev/null 2>&1; then
      local ver cluster
      ver=$(curl -s "localhost:$OS_PORT" | python3 -c "import sys,json; print(json.load(sys.stdin)['version']['number'])" 2>/dev/null || echo "?")
      cluster=$(curl -s "localhost:$OS_PORT" | python3 -c "import sys,json; print(json.load(sys.stdin)['cluster_name'])" 2>/dev/null || echo "?")
      echo "  ✅ OpenSearch ready (version: $ver, cluster: $cluster)"
      return 0
    fi
    sleep 1
  done
  echo "  ❌ OpenSearch not ready after ${max}s"
  return 1
}

OPENSEARCH_ALREADY_RUNNING=false

if curl -s "localhost:$OS_PORT" >/dev/null 2>&1; then
  echo "🔍 OpenSearch already running on localhost:$OS_PORT"
  OPENSEARCH_ALREADY_RUNNING=true
else
  echo "🔍 OpenSearch not running, setting up..."

  # Try systemd first
  if systemctl list-unit-files opensearch.service 2>/dev/null | grep -q opensearch; then
    echo "  📦 Found systemd service, starting..."
    sudo systemctl start opensearch
    if wait_for_opensearch "$MAX_WAIT"; then
      OPENSEARCH_ALREADY_RUNNING=true
    else
      echo "  ⚠️  Systemd failed, falling through to Docker..."
    fi
  fi

  if [[ "$OPENSEARCH_ALREADY_RUNNING" == "false" ]]; then
    # Ensure Docker
    if ! command -v docker >/dev/null 2>&1; then
      echo "  📦 Installing Docker..."
      sudo apt-get update -qq
      sudo apt-get install -y -qq docker.io 2>&1 | tail -3
      sudo systemctl enable docker.socket docker.service 2>/dev/null || true
      sudo systemctl start docker.socket
      sudo systemctl start docker.service
      sudo usermod -aG docker "$(whoami)" 2>/dev/null || true
      echo "  ✅ Docker installed"
    else
      echo "  ✅ Docker already installed"
    fi

    # Check existing container
    if sudo docker ps -a --format '{{.Names}}' | grep -q "^${OS_CONTAINER}$"; then
      if sudo docker ps --format '{{.Names}}' | grep -q "^${OS_CONTAINER}$"; then
        echo "  🐳 Container running, waiting..."
      else
        echo "  🐳 Container stopped, starting..."
        sudo docker start "$OS_CONTAINER"
      fi
      if wait_for_opensearch "$MAX_WAIT"; then
        OPENSEARCH_ALREADY_RUNNING=true
      else
        echo "  ⚠️  Existing container failed, recreating..."
        sudo docker rm -f "$OS_CONTAINER" 2>/dev/null || true
      fi
    fi

    if [[ "$OPENSEARCH_ALREADY_RUNNING" == "false" ]]; then
      # Set vm.max_map_count
      local_mmc=$(sysctl -n vm.max_map_count 2>/dev/null || echo "0")
      if [[ "$local_mmc" -lt 262144 ]]; then
        sudo sysctl -w vm.max_map_count=262144 >/dev/null
        if ! grep -q "vm.max_map_count" /etc/sysctl.conf 2>/dev/null; then
          echo "vm.max_map_count=262144" | sudo tee -a /etc/sysctl.conf >/dev/null
        fi
        echo "  📝 vm.max_map_count=262144"
      fi

      echo "  🐳 Starting OpenSearch $OS_VERSION..."
      sudo docker run -d --name "$OS_CONTAINER" \
        --restart unless-stopped \
        -p "$OS_PORT":9200 -p 9600:9600 \
        -e "discovery.type=single-node" \
        -e "DISABLE_SECURITY_PLUGIN=true" \
        -e "OPENSEARCH_JAVA_OPTS=-Xms${OS_MEMORY} -Xmx${OS_MEMORY}" \
        "opensearchproject/opensearch:${OS_VERSION}" 2>&1

      wait_for_opensearch "$MAX_WAIT" || { echo "❌ Failed to start OpenSearch"; exit 1; }
    fi
  fi
fi

# ──────────────────────────────────────────────────
# Part 2: Restore data
# ──────────────────────────────────────────────────

echo ""
if [[ ! -f "$DATA_FILE" ]]; then
  echo "⚠️  Data file not found: $DATA_FILE — skipping data restore"
  echo "   Use --data-file to specify the export JSON"
  echo ""
  echo "✅ OpenSearch setup complete (no data restored)."
  exit 0
fi

# Ensure opensearch-py is installed
if ! python3 -c "import opensearchpy" 2>/dev/null; then
  echo "📦 Installing opensearch-py..."
  pip install -q --break-system-packages --ignore-installed typing_extensions opensearch-py 2>&1 | tail -2 || \
  pip install -q --ignore-installed typing_extensions opensearch-py 2>&1 | tail -2
fi

echo "📥 Restoring OpenSearch data..."

python3 - "$DATA_FILE" << 'RESTORE_SCRIPT'
import json, sys, os

filepath = sys.argv[1]
from opensearchpy import OpenSearch
from opensearchpy.helpers import bulk

client = OpenSearch(hosts=["http://localhost:9200"], use_ssl=False, verify_certs=False)

with open(filepath) as f:
    data = json.load(f)

index_name = data["index_name"]
docs = data["documents"]
settings = data.get("settings", {})
mappings = data.get("mappings", {})

print(f"  Index: {index_name} ({len(docs)} documents)")

# Check if index already has data
if client.indices.exists(index=index_name):
    count = client.count(index=index_name)["count"]
    if count >= len(docs):
        print(f"  ✅ Index already has {count} docs (expected {len(docs)}), skipping")
        sys.exit(0)
    elif count > 0:
        print(f"  ⚠️  Index has {count} docs, expected {len(docs)} — will re-index")
        client.indices.delete(index=index_name)

# Create index
if not client.indices.exists(index=index_name):
    idx_settings = settings.get("index", {})
    clean = {}
    for k in ["knn", "knn.space_type", "number_of_shards", "number_of_replicas"]:
        if k in idx_settings:
            clean[k] = idx_settings[k]
    if "analysis" in idx_settings:
        clean["analysis"] = idx_settings["analysis"]
    client.indices.create(index=index_name, body={"settings": {"index": clean}, "mappings": mappings})
    print(f"  ✅ Index created")

def gen():
    for doc in docs:
        yield {"_index": index_name, "_id": doc["_id"], "_source": doc["_source"]}

success, failed = bulk(client, gen())
fail_count = len(failed) if isinstance(failed, list) else failed
print(f"  ✅ Restored: {success} docs, {fail_count} failed")
RESTORE_SCRIPT

echo ""
echo "✅ OpenSearch setup complete!"
echo "   Endpoint:  http://localhost:$OS_PORT"
echo "   Index:     budget-knowledge"
