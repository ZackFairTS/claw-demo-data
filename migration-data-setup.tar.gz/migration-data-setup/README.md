# CFO 智能助手团队 — 基础设施初始化

本包用于初始化 CFO 智能助手团队所需的数据层基础设施。在 Agent 迁移部署（`migration-small.tar.gz`）之前运行。

---

## 前提条件

- Linux (Ubuntu 22.04+)
- Python 3.10+
- AWS 凭证（IAM role 或 access keys），需要以下权限：
  - S3, Athena, Glue（用于 Athena 数据层）
  - S3 Vectors, Bedrock（用于 mem0 向量记忆）
- AWS CLI **不需要提前装**，OpenSearch 脚本会自动安装 Docker，mem0 脚本会自动装 Python 依赖

---

## 命名规则（固定）

| 资源 | 命名格式 | Region |
|------|---------|--------|
| Athena S3 桶 | `openclaw-analytics-us-east-1-{account_id}` | us-east-1 |
| Athena 数据库 | `openclaw_analytics` | us-east-1 |
| S3 Vectors 桶 | `openclaw-memory-vectors-{account_id}` | us-east-1 |
| OpenSearch | `localhost:9200`，index: `budget-knowledge` | 本地 |
| mem0 服务 | `http://127.0.0.1:8765` | 本地 |

---

## 一键安装（推荐）

```bash
curl -fsSL -o migration-data-setup.tar.gz \
  https://raw.githubusercontent.com/ZackFairTS/warcdata/main/migration-data-setup.tar.gz
tar xzf migration-data-setup.tar.gz
cd migration-data-setup
bash setup_all.sh
```

按顺序执行 Athena → OpenSearch → mem0 全部初始化。AWS CLI 未安装会自动装。

---

## 分步执行

如需单独运行某一步，先下载解压（同上），然后按需执行：

### 1. 初始化 Athena（S3 桶 + Glue 库/表/视图 + 数据上传）

```bash
bash setup_athena.sh
```

**做了什么：**
- 创建 S3 桶 `openclaw-analytics-us-east-1-{account_id}`（已存在则跳过）
- 上传 4 个 parquet 文件到 `s3://{bucket}/budget-demo/`
- 创建 Glue 数据库 `openclaw_analytics`
- 创建 4 张外部表：`budget_summary`, `budget_actuals`, `budget_plans`, `department_info`
- 创建 4 个视图：`v_budget_variance`, `v_cost_breakdown`, `v_department_trend`, `v_overrun_alert`
- 执行测试查询验证

**数据来源：** `data/` 目录下的 4 个 parquet 文件

**自定义数据目录：**
```bash
bash setup_athena.sh --data-dir /path/to/your/parquet/files
```

### 3. 初始化 OpenSearch（Docker 安装 + 知识库索引恢复）

```bash
bash setup_opensearch.sh
```

**做了什么：**
- 检查 `localhost:9200` 是否已在运行（在运行则跳过安装）
- 如果没装 Docker → 自动安装 `docker.io`
- 启动 OpenSearch 2.18.0 容器（单节点模式，512m heap）
- 设置 `vm.max_map_count=262144`（持久化到 sysctl.conf）
- 安装 `opensearch-py` Python 库
- 恢复 `budget-knowledge` 索引（43 篇文档，含向量嵌入）
- 如果索引已存在且文档数足够则跳过

**数据来源：** `opensearch-data/opensearch-budget-knowledge.json`

**自定义参数：**
```bash
bash setup_opensearch.sh --version 2.18.0 --memory 512m --data-file /path/to/export.json
```

### 4. 初始化 mem0（S3 Vectors 桶 + 服务部署 + 向量记忆恢复）

```bash
bash setup_mem0.sh
```

**做了什么：**
- 创建 S3 Vectors 桶 `openclaw-memory-vectors-{account_id}`（已存在则跳过）
- 部署 mem0 HTTP 服务到 `~/memory-s3vectors/mem0/`
- 根据 region 自动配置 Bedrock LLM 模型（us-east-1 → `us.anthropic.claude-3-haiku`）
- 安装 Python 依赖（fastapi, uvicorn, mem0ai, boto3 等）
- 创建 systemd 用户单元并启动服务
- 健康检查 `http://127.0.0.1:8765/health`
- 恢复 4 个向量索引共 255 条记忆（已有数据则跳过）

**数据来源：**
- 服务源码：`mem0-service-source/`
- 向量记忆：`mem0-vectors/` 下的 4 个 JSON 文件

**自定义参数：**
```bash
bash setup_mem0.sh --source-dir /path/to/service-source --vectors-dir /path/to/vectors
```

---

## 验证

全部完成后验证：

```bash
# Athena
python3 -c "
import boto3
client = boto3.client('athena', region_name='us-east-1')
sts = boto3.client('sts', region_name='us-east-1')
aid = sts.get_caller_identity()['Account']
resp = client.start_query_execution(
    QueryString='SELECT count(*) FROM budget_summary',
    QueryExecutionContext={'Database': 'openclaw_analytics'},
    ResultConfiguration={'OutputLocation': f's3://openclaw-analytics-us-east-1-{aid}/athena-results/'}
)
print(f'Athena query started: {resp[\"QueryExecutionId\"]}')
"

# OpenSearch
curl -s localhost:9200/budget-knowledge/_count

# mem0
curl -s localhost:8765/health
```

---

## 包内容

```
migration-data-setup/
├── README.md                 ← 本文件
├── setup_all.sh              ← 一键初始化（推荐）
├── cleanup_all.sh            ← 一键清理（测试用）
├── setup_athena.sh           ← Athena 初始化脚本
├── setup_opensearch.sh       ← OpenSearch 初始化脚本
├── setup_mem0.sh             ← mem0 初始化脚本
├── data/                     ← Athena parquet 数据 (4 files)
│   ├── budget_actuals.parquet
│   ├── budget_plans.parquet
│   ├── budget_summary.parquet
│   └── department_info.parquet
├── opensearch-data/          ← OpenSearch 索引导出 (43 docs)
│   └── opensearch-budget-knowledge.json
├── mem0-service-source/      ← mem0 HTTP 服务源码
│   ├── service.py
│   └── requirements.txt
└── mem0-vectors/             ← mem0 向量记忆 (4 indexes, 255 vectors)
    ├── mem0-cfo-assistant-vectors.json
    ├── mem0-group-t-vectors.json
    ├── mem0-memory-vectors.json
    └── mem0-tsj-vectors.json
```
