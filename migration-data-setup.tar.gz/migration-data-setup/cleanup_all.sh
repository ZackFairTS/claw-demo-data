#!/usr/bin/env bash
#
# cleanup_all.sh — 一键清理所有基础设施（Athena + OpenSearch + mem0）
#
# Usage:
#   bash cleanup_all.sh [--yes]    # --yes 跳过确认
#
set -euo pipefail

REGION="us-east-1"
AUTO_YES=false

while [[ $# -gt 0 ]]; do
  case $1 in
    --yes|-y) AUTO_YES=true; shift ;;
    *) echo "Unknown arg: $1"; exit 1 ;;
  esac
done

echo "╔══════════════════════════════════════════════╗"
echo "║    CFO 智能助手 — 基础设施一键清理            ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

# Detect account
ACCOUNT_ID=$(aws sts get-caller-identity --region "$REGION" --query Account --output text 2>/dev/null || echo "unknown")
ATHENA_BUCKET="openclaw-analytics-${REGION}-${ACCOUNT_ID}"
VECTOR_BUCKET="openclaw-memory-vectors-${ACCOUNT_ID}"

echo "将清理以下资源："
echo ""
echo "  Athena:"
echo "    - S3 桶: $ATHENA_BUCKET"
echo "    - Glue 数据库: openclaw_analytics (4 表 + 4 视图)"
echo ""
echo "  OpenSearch:"
echo "    - Docker 容器: opensearch"
echo "    - Docker 引擎 (docker.io)"
echo ""
echo "  mem0:"
echo "    - systemd 服务: mem0-service"
echo "    - 服务目录: ~/memory-s3vectors/"
echo "    - S3 Vectors 桶: $VECTOR_BUCKET"
echo ""

if [[ "$AUTO_YES" != "true" ]]; then
  read -p "确认清理？[y/N] " confirm
  if [[ "$confirm" != "y" && "$confirm" != "Y" ]]; then
    echo "已取消"
    exit 0
  fi
fi

echo ""

# ──────────────────────────────────────────────────
# 1. mem0
# ──────────────────────────────────────────────────
echo "━━━ 1/3: mem0 ━━━"

# Stop service
if systemctl --user is-active mem0-service >/dev/null 2>&1; then
  systemctl --user stop mem0-service
  echo "  ✅ 服务已停止"
fi
systemctl --user disable mem0-service 2>/dev/null || true
rm -f ~/.config/systemd/user/mem0-service.service
systemctl --user daemon-reload 2>/dev/null || true
echo "  ✅ systemd unit 已删除"

# Remove files
rm -rf ~/memory-s3vectors
echo "  ✅ ~/memory-s3vectors 已删除"

# Delete S3 Vectors bucket indexes, then bucket
if aws s3vectors get-vector-bucket --vector-bucket-name "$VECTOR_BUCKET" --region "$REGION" >/dev/null 2>&1; then
  # List and delete all indexes first
  INDEXES=$(aws s3vectors list-indexes --vector-bucket-name "$VECTOR_BUCKET" --region "$REGION" \
    --query "indexes[].indexName" --output text 2>/dev/null || echo "")
  for idx in $INDEXES; do
    aws s3vectors delete-index --vector-bucket-name "$VECTOR_BUCKET" --index-name "$idx" --region "$REGION" 2>/dev/null || true
    echo "  ✅ 索引 $idx 已删除"
  done
  aws s3vectors delete-vector-bucket --vector-bucket-name "$VECTOR_BUCKET" --region "$REGION" 2>/dev/null || true
  echo "  ✅ S3 Vectors 桶 $VECTOR_BUCKET 已删除"
else
  echo "  ⏭️ S3 Vectors 桶不存在"
fi
echo ""

# ──────────────────────────────────────────────────
# 2. OpenSearch + Docker
# ──────────────────────────────────────────────────
echo "━━━ 2/3: OpenSearch + Docker ━━━"

if command -v docker >/dev/null 2>&1; then
  sudo docker stop opensearch 2>/dev/null && echo "  ✅ 容器已停止" || echo "  ⏭️ 容器未运行"
  sudo docker rm -v opensearch 2>/dev/null && echo "  ✅ 容器+volume 已删除" || true
  # 只删除 opensearch 镜像，不卸载 Docker 本身
  sudo docker rmi opensearchproject/opensearch:2.19.1 2>/dev/null && echo "  ✅ 镜像已删除" || true
  echo "  ℹ️  Docker 保留（如需卸载请手动: sudo apt-get purge docker.io）"
else
  echo "  ⏭️ Docker 未安装"
fi
echo ""

# ──────────────────────────────────────────────────
# 3. Athena + Glue + S3
# ──────────────────────────────────────────────────
echo "━━━ 3/3: Athena ━━━"

# Drop views
for view in v_budget_variance v_cost_breakdown v_department_trend v_overrun_alert; do
  aws glue delete-table --database-name openclaw_analytics --name "$view" --region "$REGION" 2>/dev/null \
    && echo "  ✅ 视图 $view 已删除" || true
done

# Drop tables
for table in budget_summary budget_actuals budget_plans department_info; do
  aws glue delete-table --database-name openclaw_analytics --name "$table" --region "$REGION" 2>/dev/null \
    && echo "  ✅ 表 $table 已删除" || true
done

# Drop database
aws glue delete-database --name openclaw_analytics --region "$REGION" 2>/dev/null \
  && echo "  ✅ 数据库 openclaw_analytics 已删除" || echo "  ⏭️ 数据库不存在"

# Delete S3 bucket
if aws s3api head-bucket --bucket "$ATHENA_BUCKET" 2>/dev/null; then
  aws s3 rm "s3://$ATHENA_BUCKET" --recursive --region "$REGION" --quiet 2>/dev/null
  # Handle versioned objects
  python3 -c "
import boto3, sys
s3 = boto3.client('s3', region_name='$REGION')
paginator = s3.get_paginator('list_object_versions')
for page in paginator.paginate(Bucket='$ATHENA_BUCKET'):
    objects = []
    for v in page.get('Versions', []):
        objects.append({'Key': v['Key'], 'VersionId': v['VersionId']})
    for d in page.get('DeleteMarkers', []):
        objects.append({'Key': d['Key'], 'VersionId': d['VersionId']})
    if objects:
        s3.delete_objects(Bucket='$ATHENA_BUCKET', Delete={'Objects': objects})
" 2>/dev/null || true
  aws s3api delete-bucket --bucket "$ATHENA_BUCKET" --region "$REGION" 2>/dev/null
  echo "  ✅ S3 桶 $ATHENA_BUCKET 已删除"
else
  echo "  ⏭️ S3 桶不存在"
fi

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║             ✅ 清理完成！                     ║"
echo "╚══════════════════════════════════════════════╝"
