---
name: budget-control
description: |
  企业预算管控技能。当需要分析预算、查询知识库、调用记忆、协调团队时使用。
  触发词：预算、超支、分析、报告、整改、部门、Q3、财务
---

# 预算管控技能

## ⚠️ 最重要：如何调用你的团队

你必须用 `sessions_send` 工具给其他 Agent 发消息，让他们并行工作。

### 调用数据分析师（老陈）
```json
{
  "label": "data-analyst",
  "message": "老陈，帮我分析一下Q3各部门的预算超支情况。数据在 /home/ubuntu/budget-demo/data/budget_q3_2026.json，请重点分析超支结构和趋势。"
}
```

### 调用合规审计员（赵合规）
```json
{
  "label": "data-analyst", 
  "message": "赵合规，请检索知识库中关于预算超支审批流程的制度条款，以及2025年Q2的历史超支处理案例。"
}
```
注意：合规审计员的 label 是 `compliance-auditor`

```json
{
}
```

### 调用方式
使用 `sessions_send` 工具，参数：
- `message`: 你要说的话

**收到任务后，立即并行调用三个 Agent，不要自己一个人做所有事情！**

## 数据资源
- Athena数据库: `openclaw_analytics` (us-east-1, 桶名由 athena_query.py 通过 STS 自动解析)
- 快速查询: `python3 /home/ubuntu/budget-demo/scripts/athena_query.py "SQL"`
- 本地备份: /home/ubuntu/budget-demo/data/（3个JSON）
- 分析图表: /home/ubuntu/budget-demo/analysis/charts/（5张PNG）
- 分析报告: /home/ubuntu/budget-demo/analysis/budget_analysis_report.json

## 常用Athena查询
```bash
# Q3各部門超支排名
python3 scripts/athena_query.py "SELECT department, variance_rate FROM budget_summary WHERE quarter='Q3' ORDER BY variance_rate DESC"

# 超支預警
python3 scripts/athena_query.py "SELECT * FROM v_overrun_alert"

# 成本類別分析
python3 scripts/athena_query.py "SELECT category, SUM(actual) as total FROM budget_actuals WHERE quarter='Q3' GROUP BY category"
```

## 知识库检索（OpenSearch）
```bash
curl -s 'http://localhost:9200/budget-knowledge/_search' \
  -H 'Content-Type: application/json' \
  -d '{"query":{"match":{"content":"预算超支审批"}},"size":3}'
```

## 记忆系统（mem0）
```bash
curl -s -X POST http://localhost:8765/search \
  -H 'Content-Type: application/json' \
  -d '{"query":"CEO偏好","user_id":"cfo-assistant","limit":5}'
```

## 工作流程
1. 收到任务 → 先调 mem0 回忆相关记忆
2. 并行派发三个 Agent（sessions_send）
3. 自己也读数据做初步分析
4. 等待团队反馈（用 sessions_yield 等待）
5. 整合所有信息生成报告
6. 生成 HTML 报告上传 S3
