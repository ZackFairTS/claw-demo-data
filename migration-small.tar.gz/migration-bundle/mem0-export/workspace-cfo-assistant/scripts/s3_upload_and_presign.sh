#!/usr/bin/env bash
#
# s3_upload_and_presign.sh — 上传文件到 S3 并生成 presigned URL
#
# 用法:
#   bash scripts/s3_upload_and_presign.sh <本地文件路径> [S3路径前缀]
#
# 桶命名规则: openclaw-<account_id>-web（固定，当前region）
# presigned URL 优先用静态IAM密钥签名（短URL、无STS token问题）
#
# 输出: 最后一行是 presigned URL
#

set -euo pipefail

# ── 参数 ──
LOCAL_FILE="${1:?用法: $0 <本地文件路径> [S3路径前缀]}"
S3_PREFIX="${2:-reports/}"

if [[ ! -f "$LOCAL_FILE" ]]; then
  echo "❌ 文件不存在: $LOCAL_FILE" >&2
  exit 1
fi

# ── 获取 AWS 账户 ID ──
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text 2>/dev/null)
if [[ -z "$ACCOUNT_ID" ]]; then
  echo "❌ 无法获取 AWS 账户 ID，请检查凭证配置" >&2
  exit 1
fi

# ── 获取当前 EC2 所在 region ──
get_current_region() {
  # 1. EC2 IMDSv2（最权威）
  local token imds_region
  token=$(curl -s -m 2 -X PUT "http://169.254.169.254/latest/api/token" \
    -H "X-aws-ec2-metadata-token-ttl-seconds: 21600" 2>/dev/null || true)
  if [[ -n "$token" ]]; then
    imds_region=$(curl -s -m 2 -H "X-aws-ec2-metadata-token: $token" \
      "http://169.254.169.254/latest/meta-data/placement/region" 2>/dev/null || true)
    if [[ -n "$imds_region" ]]; then echo "$imds_region"; return; fi
  fi

  # 2. 环境变量
  if [[ -n "${AWS_REGION:-}" ]]; then echo "$AWS_REGION"; return; fi
  if [[ -n "${AWS_DEFAULT_REGION:-}" ]]; then echo "$AWS_DEFAULT_REGION"; return; fi

  # 3. AWS CLI 配置
  local cli_region
  cli_region=$(aws configure get region 2>/dev/null || true)
  if [[ -n "$cli_region" ]]; then echo "$cli_region"; return; fi

  echo "❌ 无法检测当前 region" >&2
  exit 1
}

REGION=$(get_current_region)
ENDPOINT="https://s3.${REGION}.amazonaws.com"
BUCKET="openclaw-${ACCOUNT_ID}-web"

echo "📍 账户: ${ACCOUNT_ID} | 区域: ${REGION}" >&2

# ── 确保桶存在于当前 region ──
ensure_bucket() {
  # 检查桶是否已存在
  if aws s3api head-bucket --bucket "$BUCKET" >/dev/null 2>&1; then
    # 桶存在，验证它在当前 region
    local loc
    loc=$(aws s3api get-bucket-location --bucket "$BUCKET" --query LocationConstraint --output text 2>/dev/null || true)
    # us-east-1 返回 "None"
    local bucket_region="$loc"
    if [[ "$loc" == "None" || "$loc" == "null" || -z "$loc" ]]; then
      bucket_region="us-east-1"
    fi

    if [[ "$bucket_region" != "$REGION" ]]; then
      echo "⚠️  桶 ${BUCKET} 存在但在 ${bucket_region}，当前 region 是 ${REGION}" >&2
      echo "🗑️  删除旧桶..." >&2
      # 清空桶内容（含版本）
      aws s3 rm "s3://${BUCKET}" --recursive --region "$bucket_region" 2>/dev/null || true
      # 删除所有版本和删除标记
      local versions
      versions=$(aws s3api list-object-versions --bucket "$BUCKET" --region "$bucket_region" \
        --query '{Objects: Versions[].{Key:Key,VersionId:VersionId}}' --output json 2>/dev/null || echo '{"Objects":null}')
      if [[ "$versions" != '{"Objects":null}' && "$versions" != *'"Objects": null'* ]]; then
        echo "$versions" | aws s3api delete-objects --bucket "$BUCKET" --region "$bucket_region" --delete file:///dev/stdin 2>/dev/null || true
      fi
      local markers
      markers=$(aws s3api list-object-versions --bucket "$BUCKET" --region "$bucket_region" \
        --query '{Objects: DeleteMarkers[].{Key:Key,VersionId:VersionId}}' --output json 2>/dev/null || echo '{"Objects":null}')
      if [[ "$markers" != '{"Objects":null}' && "$markers" != *'"Objects": null'* ]]; then
        echo "$markers" | aws s3api delete-objects --bucket "$BUCKET" --region "$bucket_region" --delete file:///dev/stdin 2>/dev/null || true
      fi
      aws s3api delete-bucket --bucket "$BUCKET" --region "$bucket_region" 2>/dev/null || true
      echo "✅ 旧桶已删除" >&2
    else
      echo "🪣 复用桶: ${BUCKET}" >&2
      return
    fi
  fi

  # 创建新桶
  echo "🪣 创建桶: ${BUCKET} (${REGION})" >&2
  if [[ "$REGION" == "us-east-1" ]]; then
    aws s3api create-bucket --bucket "$BUCKET" --region "$REGION" >/dev/null
  else
    aws s3api create-bucket --bucket "$BUCKET" --region "$REGION" \
      --create-bucket-configuration LocationConstraint="$REGION" >/dev/null
  fi

  # 默认加密
  aws s3api put-bucket-encryption --bucket "$BUCKET" \
    --server-side-encryption-configuration '{
      "Rules": [{"ApplyServerSideEncryptionByDefault": {"SSEAlgorithm": "AES256"}}]
    }' 2>/dev/null || true

  # 版本控制
  aws s3api put-bucket-versioning --bucket "$BUCKET" \
    --versioning-configuration Status=Enabled 2>/dev/null || true
}

ensure_bucket

# ── 上传文件 ──
FILENAME=$(basename "$LOCAL_FILE")
S3_KEY="${S3_PREFIX%/}/${FILENAME}"

# Content-Type
CONTENT_TYPE="application/octet-stream"
case "${FILENAME,,}" in
  *.html) CONTENT_TYPE="text/html; charset=utf-8" ;;
  *.png)  CONTENT_TYPE="image/png" ;;
  *.jpg|*.jpeg) CONTENT_TYPE="image/jpeg" ;;
  *.pdf)  CONTENT_TYPE="application/pdf" ;;
  *.json) CONTENT_TYPE="application/json" ;;
  *.csv)  CONTENT_TYPE="text/csv" ;;
esac

echo "📤 上传: ${LOCAL_FILE} → s3://${BUCKET}/${S3_KEY}" >&2
aws s3 cp "$LOCAL_FILE" "s3://${BUCKET}/${S3_KEY}" \
  --region "$REGION" \
  --content-type "$CONTENT_TYPE" \
  --quiet

# ── 生成 presigned URL（1小时有效）──
# 优先用静态IAM密钥（短URL、无STS token问题）
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SIGNER_CREDS="${SCRIPT_DIR}/.s3_signer_creds"

if [[ -f "$SIGNER_CREDS" ]]; then
  source "$SIGNER_CREDS"
  PRESIGNED_URL=$(AWS_ACCESS_KEY_ID="$S3_SIGNER_KEY_ID" \
    AWS_SECRET_ACCESS_KEY="$S3_SIGNER_SECRET_KEY" \
    AWS_SESSION_TOKEN="" \
    aws s3 presign "s3://${BUCKET}/${S3_KEY}" \
      --region "$REGION" \
      --expires-in 3600 \
      --endpoint-url "$ENDPOINT")
else
  PRESIGNED_URL=$(aws s3 presign "s3://${BUCKET}/${S3_KEY}" \
    --region "$REGION" \
    --expires-in 3600 \
    --endpoint-url "$ENDPOINT")
fi

echo "✅ 上传完成，presigned URL（1小时有效）:" >&2
echo "$PRESIGNED_URL"
