#!/usr/bin/env python3
"""
restore_mem0.py — 将导出的 mem0 记忆恢复到新环境
用法: python3 restore_mem0.py [--dry-run] [--mem0-url http://127.0.0.1:8765]
"""

import json
import sys
import time
import argparse
import os

try:
    import requests
except ImportError:
    print("需要 requests 库: pip install requests")
    sys.exit(1)

EXPORT_FILES = [
    "cfo-assistant-export.json",
    "group-t-export.json",
    "data-analyst-export.json",
    "compliance-auditor-export.json",
]


def restore(mem0_url, dry_run=False):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    total_restored = 0

    for filename in EXPORT_FILES:
        filepath = os.path.join(script_dir, filename)
        try:
            with open(filepath) as f:
                data = json.load(f)
        except FileNotFoundError:
            print(f"⚠️  跳过 {filename}（文件不存在）")
            continue

        user_id = data["user_id"]
        memories = data["memories"]

        if not memories:
            print(f"\n⏭️  {user_id}: 0 条记忆，跳过")
            continue

        print(f"\n{'='*50}")
        print(f"恢复 {user_id}: {len(memories)} 条记忆")
        print(f"{'='*50}")

        for i, mem in enumerate(memories):
            memory_text = mem.get("memory", "")
            metadata = mem.get("metadata") or {}
            metadata["original_id"] = mem.get("id", "")
            metadata["original_created_at"] = mem.get("created_at", "")
            metadata["migrated"] = True

            if dry_run:
                print(f"  [{i+1}/{len(memories)}] [DRY RUN] {memory_text[:80]}")
                continue

            try:
                resp = requests.post(
                    f"{mem0_url}/add",
                    json={
                        "messages": [
                            {"role": "user", "content": memory_text},
                            {"role": "assistant", "content": f"Restored memory for {user_id}"},
                        ],
                        "user_id": user_id,
                        "metadata": metadata,
                    },
                    timeout=30,
                )
                if resp.ok:
                    print(f"  [{i+1}/{len(memories)}] ✅ {memory_text[:60]}")
                    total_restored += 1
                else:
                    print(f"  [{i+1}/{len(memories)}] ❌ {resp.status_code}: {resp.text[:100]}")
            except Exception as e:
                print(f"  [{i+1}/{len(memories)}] ❌ Error: {e}")

            time.sleep(0.5)

    print(f"\n{'='*50}")
    if dry_run:
        print("Dry run 完成，未写入任何数据。")
    else:
        print(f"恢复完成！共写入 {total_restored} 条记忆。")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="恢复 mem0 记忆到新环境")
    parser.add_argument("--dry-run", action="store_true", help="仅预览，不实际写入")
    parser.add_argument("--mem0-url", default="http://127.0.0.1:8765", help="mem0 服务地址")
    args = parser.parse_args()
    restore(args.mem0_url, args.dry_run)
