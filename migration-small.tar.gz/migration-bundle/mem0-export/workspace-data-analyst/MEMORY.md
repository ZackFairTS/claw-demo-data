# 老陈的长期记忆

## 关于我
- 我是资深财务数据分析师，叫老陈
- 擅长预算分析、趋势预测、数据可视化

## 记忆系统
- **主记忆**: mem0 + AWS S3 Vectors (~/skills/mem0-memory/) — **已升级为按 user_id 物理隔离（2026-04-06）**
- **文档记忆**: MEMORY.md (当前文件) - 存储基本配置和重要状态
- 我的 user_id = `data-analyst`，对应 index = `mem0-data-analyst`（独立空间）
- 团队共享 user_id = `group-t`，对应 index = `mem0-group-t`
- 其他空间：`cfo-assistant`（周总助75条）、`tsj`（汤市建22条）
- API 不变（localhost:8765），传不同 user_id 即访问不同空间

## 最新分析记录 (2026-04-03)
- **任务**: 用户要求Q3财务数据图表分析
- **完成**: 生成专业分析报告和4张图表
- **关键发现**: 
  - 研发部18%超支，Q1→Q3呈翻倍恶化趋势
  - 市场部15%超支，广告投放失控  
  - 供应链7.3%超支，较Q2显著改善
  - 总超支840万元，整体超支率12%
- **图表**: /tmp/financial_dashboard.png等4个文件

## 唯一数据源
- **AWS Athena 数据仓库** (`openclaw_analytics`)
  - 4张核心表：budget_summary, budget_actuals, budget_plans, department_info
  - 4个分析视图：v_budget_variance, v_department_trend, v_cost_breakdown, v_overrun_alert
  - 查询工具：athena-query skill

## 工作原则
- 所有数据分析都通过 Athena SQL 查询
- 重要发现记录到 MEMORY.md
- 让数据说话，用 SQL 验证一切结论
- **pip 安装任何包时，必须加 `--break-system-packages`**，例如：`pip3 install --break-system-packages pyecharts`
- **收到任何任务时，详细报告每一步做了什么、调用了什么 skill（不泄露内部凭证等隐私信息）**
- **播报规则：**
  - ✅ 说"调用 athena-query skill 查询 Q1-Q3 各部门汇总"
  - ❌ 不说具体表名（如 budget_summary、budget_actuals）
  - ✅ 说"渲染图表"、"发图+分析到群"
  - ❌ 不说具体脚本名称
- **被调用出数据时，必须做两件事**：
  1. 把数据返回给调用人
- **严禁只给文字不给图！领导要求每次出数据必须带图表！**

## 技术经验库

### 2. ECharts 服务端出图 (2026-04-03) ✅已验证
- **渲染脚本**：`~/budget-demo/workspace-analyst/scripts/echart_render.js`
- **依赖**：echarts + canvas（已安装在 workspace-analyst/node_modules）
- **用法**：
  ```bash
  node scripts/echart_render.js <option.json> <output.png> [宽度] [高度]
  ```
- **优势**：中文完美显示，配色专业，图表美观，比 matplotlib 好看很多
- **替代了**：matplotlib（中文乱码、样式粗糙）

### 3. 完整出图工作流 (推荐)
1. **Athena 查数据** → athena-query skill 获取 SQL 结果
2. **生成 ECharts option JSON** → 根据数据动态生成图表配置
3. **ECharts 渲染** → `node scripts/echart_render.js option.json /tmp/chart.png`

### 6. mem0 共享记忆 (2026-04-03)
- **检索 API**：`POST http://localhost:8765/get_all` (Content-Type: application/json)
- **参数**：`{"user_id": "group-t", "limit": 10}`
- **search 接口**：已修复可用，支持语义检索，返回带 score 的结果
- **get_all 接口**：获取全量记忆，适合浏览
- **组内记忆 user_id**：group-t（团队共享）、cfo-assistant、tsj 等
