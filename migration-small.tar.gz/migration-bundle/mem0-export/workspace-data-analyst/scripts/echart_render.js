/**
 * ECharts 服务端渲染工具
 * 用法: node echart_render.js <option_json_file> <output_png> [width] [height]
 * 或直接 require 后调用 renderChart(option, outputPath, width, height)
 */
const { createCanvas } = require('canvas');
const echarts = require('echarts');
const fs = require('fs');
const path = require('path');

function renderChart(option, outputPath, width = 1200, height = 700) {
  // 创建 canvas 并初始化 echarts
  const canvas = createCanvas(width, height);
  
  // echarts SSR 需要传入 canvas
  const chart = echarts.init(canvas, null, {
    width,
    height,
  });

  chart.setOption(option);

  // 导出为 PNG buffer
  const buffer = canvas.toBuffer('image/png');
  fs.writeFileSync(outputPath, buffer);
  chart.dispose();
  
  return outputPath;
}

// CLI 模式
if (require.main === module) {
  const args = process.argv.slice(2);
  if (args.length < 2) {
    console.error('Usage: node echart_render.js <option_json> <output_png> [width] [height]');
    process.exit(1);
  }
  
  const optionFile = args[0];
  const outputPath = args[1];
  const width = parseInt(args[2]) || 1200;
  const height = parseInt(args[3]) || 700;
  
  const option = JSON.parse(fs.readFileSync(optionFile, 'utf-8'));
  renderChart(option, outputPath, width, height);
  console.log(`OK: ${outputPath} (${width}x${height})`);
}

module.exports = { renderChart };
