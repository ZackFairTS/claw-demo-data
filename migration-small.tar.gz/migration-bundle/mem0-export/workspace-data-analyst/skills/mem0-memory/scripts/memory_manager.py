#!/usr/bin/env python3
"""
财务分析师记忆管理工具
基于 mem0 + AWS S3 Vectors

用法:
  python3 memory_manager.py add "记忆内容"
  python3 memory_manager.py search "搜索关键词"
  python3 memory_manager.py list
  python3 memory_manager.py reset
"""

import os
import sys
import json
import logging
from datetime import datetime
from typing import List, Dict, Any

import boto3

# 设置日志
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# 确保 mem0 可用
try:
    from mem0 import Memory
except ImportError:
    logger.error("mem0 not installed. Run: pip install mem0ai")
    sys.exit(1)

# 配置
USER_ID = "data-analyst-chen"
AWS_REGION = "us-east-1"


def _get_account_id() -> str:
    return boto3.client("sts", region_name=AWS_REGION).get_caller_identity()["Account"]


def _get_vector_bucket_name() -> str:
    name = os.environ.get("MEM0_VECTOR_BUCKET_NAME", "")
    if not name or "{account_id}" in name:
        return f"openclaw-memory-vectors-{_get_account_id()}"
    return name


MEM0_CONFIG = {
    "vector_store": {
        "provider": "s3vectors", 
        "config": {
            "vector_bucket_name": _get_vector_bucket_name(),
            "collection_name": "analyst-chen-memory",
            "embedding_model_dims": 1024,
            "distance_metric": "cosine",
            "region_name": AWS_REGION
        }
    },
    "llm": {
        "provider": "aws_bedrock",
        "config": {
            "model": "anthropic.claude-haiku-4-5-20251001-v1:0",
            "temperature": 0.1
        }
    },
    "embedder": {
        "provider": "aws_bedrock",
        "config": {
            "model": "amazon.titan-embed-text-v2:0",
            "embedding_dims": 1024
        }
    }
}


class MemoryManager:
    def __init__(self):
        """初始化记忆管理器"""
        os.environ["AWS_REGION"] = AWS_REGION
        logger.info("初始化 mem0 记忆系统...")
        try:
            self.memory = Memory.from_config(MEM0_CONFIG)
            logger.info("✅ mem0 记忆系统初始化成功")
        except Exception as e:
            logger.error(f"❌ mem0 初始化失败: {e}")
            raise

    def add_memory(self, content: str, metadata: Dict[str, Any] = None) -> Dict:
        """添加记忆"""
        timestamp = datetime.now().isoformat()
        
        # 构造消息格式
        messages = [
            {
                "role": "user", 
                "content": content,
                "timestamp": timestamp
            }
        ]
        
        # 添加元数据
        if metadata:
            messages[0].update(metadata)
        
        logger.info(f"📝 添加记忆: {content[:50]}...")
        
        try:
            result = self.memory.add(messages, user_id=USER_ID)
            logger.info(f"✅ 记忆添加成功: {result}")
            return result
        except Exception as e:
            logger.error(f"❌ 添加记忆失败: {e}")
            return {"error": str(e)}

    def search_memory(self, query: str, limit: int = 5) -> List[Dict]:
        """搜索记忆"""
        logger.info(f"🔍 搜索记忆: {query}")
        
        try:
            results = self.memory.search(query, user_id=USER_ID, limit=limit)
            logger.info(f"✅ 找到 {len(results)} 条相关记忆")
            
            # 格式化输出
            for i, result in enumerate(results, 1):
                print(f"\n--- 记忆 {i} (相关度: {result.get('score', 'N/A'):.3f}) ---")
                print(f"内容: {result.get('memory', result.get('text', 'N/A'))}")
                print(f"ID: {result.get('id', 'N/A')}")
                if 'created_at' in result:
                    print(f"时间: {result['created_at']}")
            
            return results
        except Exception as e:
            logger.error(f"❌ 搜索失败: {e}")
            return []

    def list_all_memories(self) -> List[Dict]:
        """列出所有记忆"""
        logger.info("📋 获取所有记忆...")
        
        try:
            # 尝试不同的方法
            try:
                memories = self.memory.get_all(user_id=USER_ID)
            except AttributeError:
                memories = self.memory.get(user_id=USER_ID)
            
            if memories:
                logger.info(f"✅ 共有 {len(memories)} 条记忆")
                
                for i, memory in enumerate(memories, 1):
                    print(f"\n--- 记忆 {i} ---")
                    print(f"内容: {memory.get('memory', memory.get('text', 'N/A'))}")
                    print(f"ID: {memory.get('id', 'N/A')}")
                    if 'created_at' in memory:
                        print(f"时间: {memory['created_at']}")
            else:
                logger.info("📭 暂无记忆")
                
            return memories or []
        except Exception as e:
            logger.error(f"❌ 获取记忆失败: {e}")
            return []

    def delete_memory(self, memory_id: str) -> Dict:
        """删除指定记忆"""
        logger.info(f"🗑️ 删除记忆: {memory_id}")
        
        try:
            result = self.memory.delete(id=memory_id)
            logger.info(f"✅ 记忆删除成功")
            return result
        except Exception as e:
            logger.error(f"❌ 删除失败: {e}")
            return {"error": str(e)}

    def reset_all_memories(self) -> Dict:
        """重置所有记忆（危险操作）"""
        logger.warning("⚠️ 即将重置所有记忆...")
        confirm = input("确认要删除所有记忆吗？输入 'yes' 确认: ")
        
        if confirm.lower() != 'yes':
            logger.info("❌ 操作已取消")
            return {"cancelled": True}
        
        try:
            result = self.memory.reset(user_id=USER_ID)
            logger.info("✅ 所有记忆已重置")
            return result
        except Exception as e:
            logger.error(f"❌ 重置失败: {e}")
            return {"error": str(e)}


def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("用法:")
        print("  python3 memory_manager.py add '记忆内容'")
        print("  python3 memory_manager.py search '搜索关键词'")
        print("  python3 memory_manager.py list")
        print("  python3 memory_manager.py delete <memory_id>")
        print("  python3 memory_manager.py reset")
        sys.exit(1)
    
    action = sys.argv[1].lower()
    
    try:
        manager = MemoryManager()
        
        if action == "add":
            if len(sys.argv) < 3:
                logger.error("请提供要添加的记忆内容")
                sys.exit(1)
            content = sys.argv[2]
            result = manager.add_memory(content)
            print(json.dumps(result, indent=2, ensure_ascii=False))
            
        elif action == "search":
            if len(sys.argv) < 3:
                logger.error("请提供搜索关键词")
                sys.exit(1)
            query = sys.argv[2]
            limit = int(sys.argv[3]) if len(sys.argv) > 3 else 5
            results = manager.search_memory(query, limit)
            
        elif action == "list":
            memories = manager.list_all_memories()
            
        elif action == "delete":
            if len(sys.argv) < 3:
                logger.error("请提供要删除的记忆ID")
                sys.exit(1)
            memory_id = sys.argv[2]
            result = manager.delete_memory(memory_id)
            print(json.dumps(result, indent=2, ensure_ascii=False))
            
        elif action == "reset":
            result = manager.reset_all_memories()
            print(json.dumps(result, indent=2, ensure_ascii=False))
            
        else:
            logger.error(f"未知操作: {action}")
            sys.exit(1)
            
    except Exception as e:
        logger.error(f"程序异常: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()