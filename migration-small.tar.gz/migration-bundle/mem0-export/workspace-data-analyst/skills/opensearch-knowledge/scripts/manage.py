import os
import sys
import argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from opensearch_client import OpenSearchClient

INDEX_NAME = "openclaw-knowledge"


def show_stats(client: OpenSearchClient):
    try:
        stats = client.get_stats()
        indices = stats.get("indices", {})
        
        if INDEX_NAME in indices:
            index_stats = indices[INDEX_NAME]
            total_docs = index_stats.get("total", {}).get("docs", {}).get("count", 0)
            total_size = index_stats.get("total", {}).get("store", {}).get("size_in_bytes", 0)
            
            print(f"\nIndex: {INDEX_NAME}")
            print(f"  Documents: {total_docs}")
            print(f"  Size: {total_size / (1024*1024):.2f} MB")
        else:
            print(f"Index {INDEX_NAME} not found")
    except Exception as e:
        print(f"Error getting stats: {e}")


def list_documents(client: OpenSearchClient, limit: int = 100):
    try:
        result = client.search({"query": {"match_all": {}}, "size": limit}, size=limit)
        docs = result.get("hits", {}).get("hits", [])
        
        if not docs:
            print("No documents found.")
            return
        
        filenames = set()
        for doc in docs:
            source = doc.get("_source", {})
            filename = source.get("filename", "unknown")
            filenames.add(filename)
        
        print(f"\nIndexed files ({len(filenames)}):")
        for filename in sorted(filenames):
            print(f"  - {filename}")
        
        total = result.get("hits", {}).get("total", {}).get("value", 0)
        print(f"\nTotal chunks: {total}")
    except Exception as e:
        print(f"Error listing documents: {e}")


def delete_by_filename(client: OpenSearchClient, filename: str):
    query = {
        "query": {
            "term": {
                "filename": filename
            }
        }
    }
    
    try:
        result = client.delete_by_query(query)
        deleted = result.get("deleted", 0)
        print(f"Deleted {deleted} documents for filename: {filename}")
    except Exception as e:
        print(f"Error deleting documents: {e}")


def clear_index(client: OpenSearchClient):
    if client.index_exists(INDEX_NAME):
        print(f"Deleting index: {INDEX_NAME}")
        client.delete_index(INDEX_NAME)
        print("Index deleted.")
    else:
        print(f"Index {INDEX_NAME} does not exist.")


def main():
    parser = argparse.ArgumentParser(description="Manage OpenSearch knowledge base")
    parser.add_argument("--index-name", default=INDEX_NAME, help="Index name")
    
    subparsers = parser.add_subparsers(dest="command", help="Commands")
    
    stats_parser = subparsers.add_parser("stats", help="Show index statistics")
    list_parser = subparsers.add_parser("list", help="List indexed documents")
    list_parser.add_argument("--limit", type=int, default=100, help="Limit number of results")
    
    delete_parser = subparsers.add_parser("delete", help="Delete documents by filename")
    delete_parser.add_argument("--file", required=True, help="Filename to delete")
    
    clear_parser = subparsers.add_parser("clear", help="Clear entire index")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    client = OpenSearchClient()
    client.index_name = args.index_name
    
    if args.command == "stats":
        show_stats(client)
    elif args.command == "list":
        list_documents(client, args.limit)
    elif args.command == "delete":
        delete_by_filename(client, args.file)
    elif args.command == "clear":
        confirm = input(f"Delete index {INDEX_NAME}? This cannot be undone. (y/n): ")
        if confirm.lower() == 'y':
            clear_index(client)
        else:
            print("Cancelled.")


if __name__ == "__main__":
    main()