---
name: compliance-search
description: |
  合规审计检索技能。当需要查找企业制度、政策条款、历史案例时使用。
  触发词：制度、政策、合规、审批、案例、审计、权限
---

# 合规审计检索

## 知识库
OpenSearch 3.4 运行在 localhost:9200，索引名 `budget-knowledge`，包含8份文档43个chunks。

## 搜索方法

### 方法1：curl 命令
```bash
curl -s 'http://localhost:9200/budget-knowledge/_search' \
  -H 'Content-Type: application/json' \
  -d '{"query":{"match":{"content":"预算超支审批流程"}},"size":5,"highlight":{"fields":{"content":{}}}}' \
  | python3 -m json.tool
```

### 方法2：Python opensearchpy
```python
from opensearchpy import OpenSearch
client = OpenSearch(hosts=[{'host': 'localhost', 'port': 9200}])
results = client.search(
    index='budget-knowledge',
    body={'query': {'match': {'content': '搜索内容'}}, 'size': 5}
)
for hit in results['hits']['hits']:
    print(f"[{hit['_source'].get('filename','')}] {hit['_source']['content'][:200]}")
```

## 知识库内容概览
- 预算管理办法v3.2：超支审批流程（10%部门审批/10-20%CFO/20%+CEO）
- 审批权限矩阵：各层级审批额度
- 2025年Q2审计报告：历史超支处理案例
- 供应链风险预警机制：预警指标和流程
- 财务合规检查清单：季度检查要点
- 成本控制指导手册：降本增效措施
- 董事会第12次会议纪要：研发投入决议
- 员工薪酬与预算关系指引：人才预算审批
