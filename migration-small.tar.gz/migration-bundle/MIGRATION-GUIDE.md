# Migration Bundle Guide

> **Updated**: 2026-04-18
> **Source**: Ubuntu server running OpenClaw 2026.3.28
> **Scope**: 3-agent budget analysis team (Agent 部署 + 配置)
> **Region**: us-east-1 (固定)

---

## Prerequisites

- **基础设施已就绪**：Athena、OpenSearch、mem0 通过 `migration-data-setup.tar.gz` 提前初始化
- **OS**: Linux (Ubuntu 22.04+ recommended)
- **Python**: 3.10+
- **AWS credentials**: IAM role or access keys
- **Auto-installed**: AWS CLI v2, Python packages

## 命名规则（固定）

| 资源 | 命名格式 |
|------|---------|
| Athena S3 桶 | `openclaw-analytics-us-east-1-{account_id}` |
| Athena Output | `s3://openclaw-analytics-us-east-1-{account_id}/athena-results/` |
| S3 Vectors 桶 | `openclaw-memory-vectors-{account_id}` |
| 报告上传桶 | `openclaw-{account_id}-web` |

所有 Agent skill 和脚本按此命名规则引用，不做运行时 region 检测。

---

## Quick Start (One Command)

```bash
tar xzf migration-bundle.tar.gz
cd migration-bundle
bash scripts/restore_all.sh
```

After completion:
```bash
openclaw gateway restart
openclaw devices approve --latest   # Required: approve operator.admin repair request
openclaw status
```

如需同时恢复数据层，加 `--with-data`：
```bash
bash scripts/restore_all.sh --with-data
```

> ⚠️ Gateway 重启后必须执行 `openclaw devices approve --latest`，否则跨 Agent 通信（`sessions_send`）会报 `pairing required` 错误。

---

## Individual Scripts

| Script | What it does |
|--------|-------------|
| `scripts/deploy_agents.sh` | Deploy agent dirs, workspaces, models.json, npm deps, shared scripts |
| `scripts/merge_config.sh` | Merge 3 agents into openclaw.json (idempotent, uses default model) |
| `scripts/setup_s3_signer.sh` | Create IAM user for clean presigned URLs, save credentials |

Recommended order:
```bash
# Phase 1: Agents
bash scripts/deploy_agents.sh

# Phase 2: Config
bash scripts/merge_config.sh
bash scripts/setup_s3_signer.sh

# Phase 3: Apply
openclaw gateway restart
openclaw devices approve --latest
```

---

## Bundle Contents

```
migration-bundle/
├── MIGRATION-GUIDE.md               # This file
├── openclaw.json.reference          # Source machine's config (reference only)
│
├── scripts/                         # Migration automation scripts
│   ├── restore_all.sh               # One-shot full restore (main entry point)
│   ├── deploy_agents.sh             # Deploy agent dirs, workspaces, deps
│   ├── merge_config.sh              # Merge agents into openclaw.json
│   └── setup_s3_signer.sh           # Create IAM user for presigned URLs
│
└── mem0-export/
    ├── workspace-cfo-assistant/     # 周总助 workspace
    ├── workspace-data-analyst/      # 老陈 workspace
    ├── workspace-compliance-auditor/# 赵合规 workspace
    ├── agentdir-*/                  # Agent personality files (SOUL.md)
    ├── *-vectors.json               # mem0 vector exports (full vectors + metadata)
    ├── service-source/              # mem0 service source code
    └── plugin-source/               # OpenClaw memory-s3vectors plugin
```

## Key Files Per Agent

### 周总助 (cfo-assistant) — Coordinator
- `MEMORY.md` — Work rules, lessons learned, team coordination patterns
- `scripts/s3_upload_and_presign.sh` — HTML report upload + presigned URL (桶: `openclaw-{account_id}-web`)
- `scripts/.s3_signer_creds` — IAM static credentials (created by setup_s3_signer.sh)
- `skills/budget-control/` — Budget control skill (Athena 桶: `openclaw-analytics-us-east-1-{account_id}`)

### 老陈 (data-analyst) — Data Analysis
- `MEMORY.md` — Athena queries, ECharts workflow, tech experience
- `scripts/echart_render.js` — Server-side ECharts rendering
- `scripts/athena_query.py` — Athena SQL query helper (region: us-east-1, 桶: `openclaw-analytics-us-east-1-{account_id}`)
- `skills/athena-query/` — AWS Athena query skill
- `skills/opensearch-knowledge/` — OpenSearch search skill
- `skills/mem0-memory/` — mem0 memory skill (桶: `openclaw-memory-vectors-{account_id}`)

### 赵合规 (compliance-auditor) — Compliance
- `MEMORY.md` — Policy knowledge, OpenSearch usage
- `skills/compliance-search/` — Compliance search skill
- `Q3_Compliance_Review.md` — Q3 review document

---

## Post-Migration Checklist

- [ ] `openclaw gateway restart` 完成
- [ ] `openclaw devices approve --latest` 批准 operator.admin repair 请求
- [ ] `openclaw status` shows all 3 agents
- [ ] Each agent responds without "No API key" errors
- [ ] CFO assistant can spawn/dispatch to data-analyst and compliance-auditor
- [ ] Main agent can `sessions_send` to cfo-assistant
- [ ] Athena: `python3 ~/budget-demo/scripts/athena_query.py "SELECT * FROM budget_summary LIMIT 3"`
- [ ] OpenSearch: `curl localhost:9200/budget-knowledge/_count`
- [ ] mem0: `curl localhost:8765/health`

### Cross-Agent Communication

迁移脚本 (`merge_config.sh`) 已自动配置以下两项，支持跨 agent 通信：

- `tools.sessions.visibility: "all"` — 跨 agent session 可见
- `tools.agentToAgent.allow: ["main", "cfo-assistant", "data-analyst", "compliance-auditor"]` — 所有 agent 互相可通信

#### sessions_send（平级通信，推荐用于 main → cfo-assistant）

```
sessions_send(
  sessionKey: "agent:cfo-assistant:main",
  message: "帮我分析一下 Q3 预算执行情况",
  timeoutSeconds: 60
)
```

| 目标 Agent | sessionKey |
|-----------|-----------|
| cfo-assistant（周总助） | `agent:cfo-assistant:main` |
| data-analyst（老陈） | `agent:data-analyst:main` |
| compliance-auditor（赵合规） | `agent:compliance-auditor:main` |

#### sessions_spawn（父子关系，推荐用于 cfo-assistant → 老陈/赵合规）

```
sessions_spawn(
  agentId: "data-analyst",
  mode: "run",
  task: "查询 Q3 各部门预算执行率",
  runTimeoutSeconds: 120
)
```

### Device Permissions

Gateway 重启后，内部客户端自动发起 `operator.admin` repair 请求：

```bash
openclaw devices approve --latest
```

---

## Notes
- Feishu (飞书) integrations have been removed. Report output is HTML + S3 presigned URL.
- `models.json` is auto-generated per-machine; `deploy_agents.sh` copies it from the main agent.
- The S3 signer IAM user has minimal permissions (s3:GetObject only).
- All scripts are idempotent — safe to re-run.
- 基础设施初始化（Athena/OpenSearch/mem0）已独立到 `migration-data-setup.tar.gz`，本包只负责 Agent 部署和配置。
