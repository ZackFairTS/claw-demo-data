# CFO 智能助手团队 — 迁移包（应用层）

本包恢复 CFO 智能助手团队的 **Agent 配置、workspace 文件、Skill、OpenClaw 插件注册**。

> 💡 数据层（Athena / OpenSearch / mem0）由 `migration-data-setup.tar.gz` 单独管理，本包默认假设数据层已就绪。

---

## ⚡ 快速恢复（推荐）

```bash
bash scripts/restore_all.sh
```

恢复完成后执行：

```bash
openclaw gateway restart
openclaw devices approve --latest   # ⚠️ 必须：批准 operator.admin 权限，否则跨 Agent 通信会报 pairing required
openclaw status
```

如需同时恢复数据层，加 `--with-data`：

```bash
bash scripts/restore_all.sh --with-data
```

也可以单独加某一层：`--with-athena` / `--with-opensearch` / `--with-mem0`

---

## 手动分步恢复

如需逐步执行，**必须按以下顺序完成所有步骤**：

### Phase 1: Agent 部署

| 步骤 | 内容 | 脚本/文档 |
|------|------|-----------|
| **1a** | Workspace 文件 + Agent 配置 + 注册 | `bash scripts/deploy_agents.sh` |
| **1b** | memory-s3vectors 插件 | 见 [mem0-export/IMPLEMENTATION-GUIDE.md](mem0-export/IMPLEMENTATION-GUIDE.md) |

### Phase 2: 配置

| 步骤 | 内容 | 脚本/文档 |
|------|------|-----------|
| **2a** | 合并 openclaw.json 配置 | `bash scripts/merge_config.sh`，参考 [openclaw.json.reference](openclaw.json.reference) |
| **2b** | S3 签名服务（可选） | `bash scripts/setup_s3_signer.sh` |

### Phase 3: 生效

| 步骤 | 内容 | 命令 |
|------|------|------|
| **3a** | 重启 Gateway | `openclaw gateway restart` |
| **3b** | 批准设备权限（⚠️ 必须） | `openclaw devices approve --latest` |

> ⚠️ Gateway 重启后必须执行 `openclaw devices approve --latest` 批准 `operator.admin` repair 请求，否则 `sessions_send` 跨 Agent 通信会报 `pairing required` 错误。

---

## 命名规则

所有 `{account_id}` 由代码通过 STS 自动解析，无需手动替换。

| 资源 | 命名格式 | Region |
|------|---------|--------|
| Athena S3 桶 | `openclaw-analytics-us-east-1-<account_id>` | us-east-1 (固定) |
| Athena 数据库 | `openclaw_analytics` | us-east-1 |
| S3 Vectors 桶 | `openclaw-memory-vectors-<account_id>` | us-east-1 (固定) |
| mem0 服务 | `http://127.0.0.1:8765` | — |
| OpenSearch | `http://localhost:9200`, index: `budget-knowledge` | — |
| 报告上传桶 | `openclaw-<account_id>-web` | 跟随 EC2 region |

---

## 包含内容

```
migration-bundle/
├── README.md                    ← 你在这里（唯一入口）
├── openclaw.json.reference      ← 完整配置参考
├── scripts/                     ← 部署脚本
│   ├── restore_all.sh           ← 一键恢复（推荐）
│   ├── deploy_agents.sh
│   ├── merge_config.sh
│   └── setup_s3_signer.sh
└── mem0-export/                 ← Agent workspace + 配置 + 插件
    ├── *-export.json            ← Agent 导出配置（4 个）
    ├── workspace-*/             ← 3 个 Agent 的 workspace 文件
    ├── agentdir-*/              ← 3 个 Agent 的配置（SOUL.md + models.json）
    ├── plugin-source/           ← memory-s3vectors OpenClaw 插件
    └── IMPLEMENTATION-GUIDE.md  ← 插件安装指南
```

## Agent 架构

- **cfo-assistant**（主 Agent）→ 可调用 data-analyst + compliance-auditor
- **data-analyst** → Athena 查询 + OpenSearch 知识库 + EChart 图表
- **compliance-auditor** → 合规政策检索 + 审计
- **group-t** → 团队共享记忆空间

---

## 跨 Agent 通信

迁移脚本已自动配置：

- `tools.sessions.visibility: "all"`
- `tools.agentToAgent.allow: ["main", "cfo-assistant", "data-analyst", "compliance-auditor"]`

使用 `sessions_send` 给 Agent 发消息：

| 目标 Agent | sessionKey |
|-----------|-----------|
| cfo-assistant（周总助） | `agent:cfo-assistant:main` |
| data-analyst（老陈） | `agent:data-analyst:main` |
| compliance-auditor（赵合规） | `agent:compliance-auditor:main` |
