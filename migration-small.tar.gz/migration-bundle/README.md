# CFO 智能助手团队 — Agent 迁移包

## 前提：基础设施已就绪

本迁移包只负责 Agent 部署和配置。以下基础设施需提前通过 `migration-data-setup.tar.gz` 初始化：

| 服务 | 资源 |
|------|------|
| Athena | S3 桶 `openclaw-analytics-us-east-1-{account_id}` + Glue 库/表/视图 |
| OpenSearch | `localhost:9200` + `budget-knowledge` 索引 (43 docs) |
| mem0 | S3 Vectors 桶 `openclaw-memory-vectors-{account_id}` + 服务 + 255 vectors |

---

## 一键部署

```bash
bash scripts/restore_all.sh --region us-east-1
```

完成后执行：

```bash
openclaw gateway restart
openclaw devices approve --latest   # ⚠️ 必须：批准 operator.admin 权限
openclaw status
```

---

## 手动分步

```bash
# 1. 部署 agent 目录、workspace、依赖
bash scripts/deploy_agents.sh

# 2. 合并配置到 openclaw.json
bash scripts/merge_config.sh

# 3. 创建 S3 签名 IAM 用户（可选，用于报告 presigned URL）
bash scripts/setup_s3_signer.sh

# 4. 生效
openclaw gateway restart
openclaw devices approve --latest
```

---

## 包含内容

```
migration-bundle/
├── README.md
├── MIGRATION-GUIDE.md
├── openclaw.json.reference
├── scripts/
│   ├── restore_all.sh          ← 一键部署入口
│   ├── deploy_agents.sh        ← 部署 agent 目录 + workspace + npm 依赖
│   ├── merge_config.sh         ← 合并 agents 到 openclaw.json
│   └── setup_s3_signer.sh      ← 创建 IAM 用户（presigned URL）
└── mem0-export/
    ├── agentdir-*/             ← 3 个 agent 的 SOUL.md + models.json
    ├── workspace-cfo-assistant/    ← 周总助 workspace (MEMORY.md, skills, scripts)
    ├── workspace-data-analyst/     ← 老陈 workspace (MEMORY.md, skills, scripts)
    ├── workspace-compliance-auditor/ ← 赵合规 workspace (MEMORY.md, skills)
    ├── plugin-source/          ← memory-s3vectors OpenClaw 插件
    └── IMPLEMENTATION-GUIDE.md ← 插件部署说明
```

## Agent 架构

- **cfo-assistant**（周总助）→ 可调用 data-analyst + compliance-auditor
- **data-analyst**（老陈）→ Athena 查询 + OpenSearch 知识库 + EChart 图表
- **compliance-auditor**（赵合规）→ 合规政策检索 + 审计
