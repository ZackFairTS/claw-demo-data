#!/usr/bin/env bash
#
# setup_s3_signer.sh — Create IAM user for clean S3 presigned URLs
#
# EC2 instance role STS credentials produce presigned URLs with very long Security-Token
# parameters that can get corrupted in transit. This creates a dedicated IAM user with
# static credentials for signing short, stable presigned URLs.
#
set -euo pipefail

BUDGET_DIR="$HOME/budget-demo"
CREDS_FILE="$BUDGET_DIR/workspace-cfo/scripts/.s3_signer_creds"
USER_NAME="s3-report-signer"
REGION="${AWS_REGION:-ap-northeast-1}"

echo "🔑 Setting up S3 presigned URL signer..."

# ── Check if user already exists ──
if aws iam get-user --user-name "$USER_NAME" >/dev/null 2>&1; then
  echo "  ⚠️  IAM user '$USER_NAME' already exists."
  if [[ -f "$CREDS_FILE" ]]; then
    echo "  ✅ Credentials file already exists at $CREDS_FILE"
    echo "  Skipping creation."
    exit 0
  else
    echo "  Credentials file missing. Creating new access key..."
  fi
else
  # ── Create IAM user ──
  echo "  Creating IAM user: $USER_NAME"
  aws iam create-user --user-name "$USER_NAME" >/dev/null

  # ── Attach minimal policy (s3:GetObject on openclaw-reports-* and openclaw-analytics-*) ──
  POLICY=$(cat << 'POLICY_EOF'
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": ["s3:GetObject"],
      "Resource": [
        "arn:aws:s3:::openclaw-reports-*/*",
        "arn:aws:s3:::openclaw-analytics-*/*"
      ]
    }
  ]
}
POLICY_EOF
  )
  aws iam put-user-policy --user-name "$USER_NAME" --policy-name s3-read-reports \
    --policy-document "$POLICY"
  echo "  ✅ IAM user created with s3:GetObject policy"
fi

# ── Create access key ──
echo "  Generating access key..."
KEY_OUTPUT=$(aws iam create-access-key --user-name "$USER_NAME" --output json)
KEY_ID=$(echo "$KEY_OUTPUT" | python3 -c "import json,sys;print(json.load(sys.stdin)['AccessKey']['AccessKeyId'])")
SECRET=$(echo "$KEY_OUTPUT" | python3 -c "import json,sys;print(json.load(sys.stdin)['AccessKey']['SecretAccessKey'])")

# ── Write credentials file ──
mkdir -p "$(dirname "$CREDS_FILE")"
cat > "$CREDS_FILE" << EOF
# IAM user: $USER_NAME
# Created $(date -u +%Y-%m-%d) for generating clean presigned URLs without STS Security-Token
export S3_SIGNER_KEY_ID=$KEY_ID
export S3_SIGNER_SECRET_KEY='$SECRET'
EOF
chmod 600 "$CREDS_FILE"

echo "  ✅ Credentials saved to $CREDS_FILE"
echo ""
echo "✅ S3 signer setup complete!"
echo "   IAM user: $USER_NAME"
echo "   Creds: $CREDS_FILE"
echo "   The s3_upload_and_presign.sh script will source this file automatically."
