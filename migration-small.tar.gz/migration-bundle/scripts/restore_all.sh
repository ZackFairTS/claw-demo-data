#!/usr/bin/env bash
#
# restore_all.sh — One-shot agent migration restore
#
# 前提：基础设施（Athena/OpenSearch/mem0）已通过 migration-data-setup 初始化
#
# Usage:
#   bash scripts/restore_all.sh [--region us-east-1]
#
# Runs:
#   1. Install missing dependencies (AWS CLI, etc.)
#   2. Deploy agents (dirs, workspaces, models.json, npm deps)
#   3. Merge openclaw.json config
#   4. Setup S3 presigned URL signer
#   5. Verify
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BUNDLE_DIR="$(dirname "$SCRIPT_DIR")"
REGION=""

while [[ $# -gt 0 ]]; do
  case $1 in
    --region) REGION="$2"; shift 2 ;;
    -h|--help)
      echo "Usage: bash $0 [--region REGION]"
      exit 0 ;;
    *) echo "Unknown arg: $1"; exit 1 ;;
  esac
done

# ── Detect region ──
if [[ -z "$REGION" ]]; then
  IMDS_TOKEN=$(curl -s -X PUT "http://169.254.169.254/latest/api/token" \
    -H "X-aws-ec2-metadata-token-ttl-seconds: 5" --connect-timeout 2 2>/dev/null || true)
  if [[ -n "$IMDS_TOKEN" ]]; then
    REGION=$(curl -s -H "X-aws-ec2-metadata-token: $IMDS_TOKEN" \
      http://169.254.169.254/latest/meta-data/placement/region --connect-timeout 2 2>/dev/null || true)
  fi
  [[ -z "$REGION" ]] && REGION="${AWS_REGION:-${AWS_DEFAULT_REGION:-us-east-1}}"
fi
export AWS_REGION="$REGION"

# ── Dependencies ──
echo "🔍 Checking dependencies..."

NEED_APT=()
command -v unzip &>/dev/null || NEED_APT+=(unzip)
command -v python3 &>/dev/null || NEED_APT+=(python3 python3-pip)

if [[ ${#NEED_APT[@]} -gt 0 ]]; then
  echo "  📦 Installing: ${NEED_APT[*]}"
  sudo apt-get update -qq && sudo apt-get install -y -qq "${NEED_APT[@]}" 2>&1 | tail -3
fi

if ! command -v aws &>/dev/null; then
  echo "  📦 Installing AWS CLI v2..."
  TMPDIR=$(mktemp -d)
  curl -sL "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "$TMPDIR/awscliv2.zip"
  unzip -q -o "$TMPDIR/awscliv2.zip" -d "$TMPDIR"
  sudo "$TMPDIR/aws/install" --update 2>&1 | tail -1
  rm -rf "$TMPDIR"
  echo "  ✅ AWS CLI installed"
fi

echo "  ✅ All dependencies ready"
echo ""

echo "╔══════════════════════════════════════════════╗"
echo "║       OpenClaw 3-Agent Migration Restore     ║"
echo "╚══════════════════════════════════════════════╝"
echo ""
echo "Region: $REGION"
echo "Bundle: $BUNDLE_DIR"
echo ""

# ── Preflight: verify infra ──
echo "🔍 Verifying infrastructure..."
INFRA_OK=true

if curl -s localhost:9200 >/dev/null 2>&1; then
  echo "  ✅ OpenSearch running"
else
  echo "  ❌ OpenSearch not running (localhost:9200)"
  INFRA_OK=false
fi

if curl -s http://127.0.0.1:8765/health >/dev/null 2>&1; then
  echo "  ✅ mem0 running"
else
  echo "  ❌ mem0 not running (localhost:8765)"
  INFRA_OK=false
fi

ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text 2>/dev/null || echo "")
if [[ -n "$ACCOUNT_ID" ]]; then
  ATHENA_BUCKET="openclaw-analytics-us-east-1-${ACCOUNT_ID}"
  if aws s3api head-bucket --bucket "$ATHENA_BUCKET" 2>/dev/null; then
    echo "  ✅ Athena bucket exists: $ATHENA_BUCKET"
  else
    echo "  ❌ Athena bucket not found: $ATHENA_BUCKET"
    INFRA_OK=false
  fi
fi

if [[ "$INFRA_OK" == "false" ]]; then
  echo ""
  echo "  ⚠️  Infrastructure not fully ready."
  echo "     Run migration-data-setup/setup_all.sh first."
  echo "     Continuing anyway (agent deployment doesn't require infra)..."
fi
echo ""

# ═══════════════════════════════════════════════════
# Phase 1: Agent Deployment
# ═══════════════════════════════════════════════════
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Phase 1: Agent Deployment"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
bash "$SCRIPT_DIR/deploy_agents.sh"
echo ""

# ═══════════════════════════════════════════════════
# Phase 2: OpenClaw Config
# ═══════════════════════════════════════════════════
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Phase 2: OpenClaw Config"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
bash "$SCRIPT_DIR/merge_config.sh"
echo ""
bash "$SCRIPT_DIR/setup_s3_signer.sh"
echo ""

# ═══════════════════════════════════════════════════
# Verification
# ═══════════════════════════════════════════════════
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Verification"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

PASS=0
FAIL=0

check() {
  local label="$1"; shift
  if "$@" >/dev/null 2>&1; then
    echo "  ✅ $label"; ((PASS++)) || true
  else
    echo "  ❌ $label"; ((FAIL++)) || true
  fi
}

check "Agent dir: cfo-assistant" test -f "$HOME/.openclaw/agents/cfo-assistant/agent/SOUL.md"
check "Agent dir: data-analyst" test -f "$HOME/.openclaw/agents/data-analyst/agent/SOUL.md"
check "Agent dir: compliance-auditor" test -f "$HOME/.openclaw/agents/compliance-auditor/agent/SOUL.md"
check "Workspace: CFO" test -f "$HOME/budget-demo/workspace-cfo/MEMORY.md"
check "Workspace: Analyst" test -f "$HOME/budget-demo/workspace-analyst/MEMORY.md"
check "Workspace: Auditor" test -f "$HOME/budget-demo/workspace-auditor/MEMORY.md"
check "athena_query.py" test -f "$HOME/budget-demo/scripts/athena_query.py"
check "S3 presign script" test -f "$HOME/budget-demo/workspace-cfo/scripts/s3_upload_and_presign.sh"
check "S3 signer creds" test -f "$HOME/budget-demo/workspace-cfo/scripts/.s3_signer_creds"

echo ""
echo "Results: $PASS passed, $FAIL failed"
echo ""

if [[ $FAIL -eq 0 ]]; then
  echo "╔══════════════════════════════════════════════╗"
  echo "║          ✅ Migration complete!              ║"
  echo "╚══════════════════════════════════════════════╝"
else
  echo "╔══════════════════════════════════════════════╗"
  echo "║    ⚠️  Migration completed with warnings     ║"
  echo "╚══════════════════════════════════════════════╝"
fi

echo ""
echo "Next steps:"
echo "  1. openclaw gateway restart"
echo "  2. openclaw devices approve --latest"
echo "  3. openclaw status"
