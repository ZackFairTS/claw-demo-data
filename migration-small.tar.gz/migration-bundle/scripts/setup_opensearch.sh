#!/usr/bin/env bash
#
# setup_opensearch.sh — Ensure OpenSearch is running (Docker or systemd)
#
# Checks in order:
#   1. Already running on localhost:9200? → done
#   2. Systemd opensearch service exists? → start it
#   3. Docker available + opensearch container exists? → start it
#   4. Docker available + no container? → pull and run
#   5. No Docker? → install docker.io via apt, then pull and run
#
# Usage:
#   bash scripts/setup_opensearch.sh [--version 2.18.0] [--memory 512m]
#
set -euo pipefail

OS_VERSION="${OS_VERSION:-2.18.0}"
OS_MEMORY="${OS_MEMORY:-512m}"
OS_CONTAINER="opensearch"
OS_PORT=9200
MAX_WAIT=60

while [[ $# -gt 0 ]]; do
  case $1 in
    --version) OS_VERSION="$2"; shift 2 ;;
    --memory) OS_MEMORY="$2"; shift 2 ;;
    -h|--help)
      echo "Usage: bash $0 [--version VERSION] [--memory HEAP_SIZE]"
      echo "  --version   OpenSearch version (default: 2.18.0)"
      echo "  --memory    JVM heap size (default: 512m)"
      exit 0 ;;
    *) echo "Unknown arg: $1"; exit 1 ;;
  esac
done

echo "🔍 Setting up OpenSearch..."
echo "   Version: $OS_VERSION | Heap: $OS_MEMORY"
echo ""

wait_for_opensearch() {
  local max=$1
  echo "  ⏳ Waiting for OpenSearch to be ready (up to ${max}s)..."
  for i in $(seq 1 "$max"); do
    if curl -s "localhost:$OS_PORT" >/dev/null 2>&1; then
      echo "  ✅ OpenSearch is ready!"
      curl -s "localhost:$OS_PORT" | python3 -c "import sys,json; d=json.load(sys.stdin); print(f'     Version: {d[\"version\"][\"number\"]} | Cluster: {d[\"cluster_name\"]}')" 2>/dev/null || true
      return 0
    fi
    sleep 1
  done
  echo "  ❌ OpenSearch did not become ready within ${max}s"
  return 1
}

# ── Check 1: Already running? ──
if curl -s "localhost:$OS_PORT" >/dev/null 2>&1; then
  echo "  ✅ OpenSearch already running on localhost:$OS_PORT"
  curl -s "localhost:$OS_PORT" | python3 -c "import sys,json; d=json.load(sys.stdin); print(f'     Version: {d[\"version\"][\"number\"]} | Cluster: {d[\"cluster_name\"]}')" 2>/dev/null || true
  exit 0
fi

# ── Check 2: Systemd service? ──
if systemctl list-unit-files opensearch.service >/dev/null 2>&1 && \
   systemctl list-unit-files opensearch.service | grep -q opensearch; then
  echo "  📦 Found systemd opensearch service, starting..."
  sudo systemctl start opensearch
  if wait_for_opensearch "$MAX_WAIT"; then
    exit 0
  fi
  echo "  ⚠️  Systemd service failed to start, falling through to Docker..."
fi

# ── Check 3/4/5: Docker path ──
install_docker() {
  echo "  📦 Docker not found. Installing docker.io via apt..."
  sudo apt-get update -qq
  sudo apt-get install -y -qq docker.io 2>&1 | tail -3
  sudo systemctl start docker
  sudo systemctl enable docker 2>/dev/null || true
  # Add current user to docker group (takes effect on next login, but sudo works now)
  sudo usermod -aG docker "$(whoami)" 2>/dev/null || true
  echo "  ✅ Docker installed and started"
}

run_opensearch_container() {
  echo "  🐳 Starting OpenSearch $OS_VERSION in Docker..."

  # Ensure vm.max_map_count is set (required by OpenSearch)
  local current_map_count
  current_map_count=$(sysctl -n vm.max_map_count 2>/dev/null || echo "0")
  if [[ "$current_map_count" -lt 262144 ]]; then
    echo "  📝 Setting vm.max_map_count=262144..."
    sudo sysctl -w vm.max_map_count=262144 >/dev/null
    # Persist across reboots
    if ! grep -q "vm.max_map_count" /etc/sysctl.conf 2>/dev/null; then
      echo "vm.max_map_count=262144" | sudo tee -a /etc/sysctl.conf >/dev/null
      echo "  📝 Persisted vm.max_map_count in /etc/sysctl.conf"
    fi
  fi

  sudo docker run -d --name "$OS_CONTAINER" \
    --restart unless-stopped \
    -p "$OS_PORT":9200 -p 9600:9600 \
    -e "discovery.type=single-node" \
    -e "DISABLE_SECURITY_PLUGIN=true" \
    -e "OPENSEARCH_JAVA_OPTS=-Xms${OS_MEMORY} -Xmx${OS_MEMORY}" \
    "opensearchproject/opensearch:${OS_VERSION}" 2>&1

  wait_for_opensearch "$MAX_WAIT"
}

# Check if docker command exists
if ! command -v docker >/dev/null 2>&1; then
  install_docker
fi

# Check if container already exists
if sudo docker ps -a --format '{{.Names}}' | grep -q "^${OS_CONTAINER}$"; then
  # Container exists — check if running
  if sudo docker ps --format '{{.Names}}' | grep -q "^${OS_CONTAINER}$"; then
    echo "  🐳 OpenSearch container exists and is running, waiting for readiness..."
  else
    echo "  🐳 OpenSearch container exists but stopped, starting..."
    sudo docker start "$OS_CONTAINER"
  fi
  if wait_for_opensearch "$MAX_WAIT"; then
    exit 0
  else
    echo "  ⚠️  Existing container failed. Removing and recreating..."
    sudo docker rm -f "$OS_CONTAINER" 2>/dev/null || true
  fi
fi

# Pull and run fresh container
run_opensearch_container

echo ""
echo "✅ OpenSearch setup complete!"
echo "   Container: $OS_CONTAINER"
echo "   Endpoint: http://localhost:$OS_PORT"
echo "   Restart policy: unless-stopped"
echo ""
echo "   Manage: sudo docker {start|stop|restart|logs} $OS_CONTAINER"
