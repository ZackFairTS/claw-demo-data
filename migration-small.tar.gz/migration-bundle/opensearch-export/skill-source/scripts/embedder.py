import os
import json
import boto3
from typing import List, Optional


class TitanEmbedder:
    def __init__(self, model_id: str = "amazon.titan-embed-text-v2:0", region: str = None):
        self.model_id = model_id
        self.region = region or os.getenv("AWS_REGION", "ap-northeast-1")
        self.client = boto3.client("bedrock-runtime", region_name=self.region)
    
    def embed(self, text: str) -> List[float]:
        payload = {
            "inputText": text
        }
        
        response = self.client.invoke_model(
            modelId=self.model_id,
            contentType="application/json",
            accept="application/json",
            body=json.dumps(payload)
        )
        
        result = json.loads(response["body"].read())
        return result["embedding"]
    
    def embed_batch(self, texts: List[str], batch_size: int = 10) -> List[List[float]]:
        embeddings = []
        
        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]
            for text in batch:
                try:
                    emb = self.embed(text)
                    embeddings.append(emb)
                except Exception as e:
                    print(f"Error embedding text: {e}")
                    embeddings.append([0.0] * 1024)
        
        return embeddings


class MockEmbedder:
    def __init__(self, dimension: int = 1024):
        self.dimension = dimension
    
    def embed(self, text: str) -> List[float]:
        import hashlib
        hash_val = int(hashlib.md5(text.encode()).hexdigest(), 16)
        import random
        random.seed(hash_val % (2**32))
        return [random.random() for _ in range(self.dimension)]
    
    def embed_batch(self, texts: List[str]) -> List[List[float]]:
        return [self.embed(text) for text in texts]


def get_embedder(use_mock: bool = False) -> any:
    if use_mock:
        return MockEmbedder()
    return TitanEmbedder()