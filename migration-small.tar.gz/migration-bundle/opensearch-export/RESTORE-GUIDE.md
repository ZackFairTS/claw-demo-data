# OpenSearch 知识库恢复（仅 OpenSearch 部分）

> ⚠️ **本文档仅覆盖 OpenSearch 知识库的恢复。完整恢复流程（含 Athena、mem0、Agent 部署等）请看根目录 [README.md](../README.md)。**

## 导出内容

| 索引名 | 文档数 | 说明 |
|---|---|---|
| budget-knowledge | 43 | 预算知识库（审计报告、预算政策、董事会决议等） |

字段：`title`、`content`（文本）、`category`、`file`、`timestamp`，纯文本搜索无向量。

## 前置条件

- **OpenSearch 2.9+** — 如果没有安装，运行 `bash scripts/setup_opensearch.sh` 自动安装（优先检查 systemd 服务，无则通过 Docker 安装）
- **Python 3** + `opensearch-py`（`pip install opensearch-py`）

## 恢复

```bash
cd /path/to/opensearch-export

# 预览
python3 restore_opensearch.py --dry-run

# 执行
python3 restore_opensearch.py

# 指定地址
python3 restore_opensearch.py --url http://192.168.1.100:9200
```

## 验证

```bash
curl -s "http://localhost:9200/budget-knowledge/_count" | python3 -m json.tool
curl -s -X POST "http://localhost:9200/budget-knowledge/_search" \
  -H "Content-Type: application/json" \
  -d '{"query": {"match": {"content": "预算超支"}}, "size": 3}' | python3 -m json.tool | head -30
```

## 注意

- 原环境禁用了安全插件，新环境如启用需配置认证
- 索引名可修改：编辑 JSON 文件中的 `index_name` 字段
