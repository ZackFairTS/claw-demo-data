# opensearch-knowledge 完整实现指南

本文档描述如何在新环境中从零搭建基于 OpenSearch 的知识库系统，支持向量 + 关键词混合搜索。

## 架构概览

```
Agent / 用户
    ↓ (CLI 或脚本调用)
Python 脚本集 (ingest / search / manage)
    ↓
┌──────────────────────────────────┐
│  OpenSearch 2.11 (本地部署)       │
│  ├── 全文检索 (BM25 + CJK 分词)  │
│  └── 向量搜索 (k-NN, 1024 维)    │
│                                  │
│  Bedrock Titan v2 (生成 embedding)│
└──────────────────────────────────┘
```

**两种搜索模式：**
- `openclaw-knowledge`：向量 + 关键词混合搜索（需要 Bedrock embedding）
- `budget-knowledge`：纯关键词搜索（无向量，不依赖 Bedrock）

## 前置条件

### 软件
- Ubuntu/Debian 或其他 Linux
- Python 3.8+
- （可选）AWS credentials（仅向量搜索需要 Bedrock）

## 第一步：安装 OpenSearch

### 方案一：APT 安装（推荐）

```bash
# 添加 OpenSearch 仓库
curl -o- https://artifacts.opensearch.org/publickeys/opensearch.pgp | sudo gpg --dearmor -o /usr/share/keyrings/opensearch-keyring
echo "deb [signed-by=/usr/share/keyrings/opensearch-keyring] https://artifacts.opensearch.org/releases/bundle/opensearch/2.x/apt stable main" | sudo tee /etc/apt/sources.list.d/opensearch-2.x.list

sudo apt-get update
sudo apt-get install opensearch
```

### 方案二：Docker（更简单）

```bash
docker run -d --name opensearch \
  -p 9200:9200 \
  -e "discovery.type=single-node" \
  -e "plugins.security.disabled=true" \
  -e "OPENSEARCH_INITIAL_ADMIN_PASSWORD=admin" \
  opensearchproject/opensearch:2.11.0
```

### 配置要点

无论哪种安装方式，确保：

1. **单节点模式**：`discovery.type=single-node`
2. **禁用安全插件**（开发环境）：`plugins.security.disabled=true`
3. **内存**：默认 1GB heap，小内存机器改为 512MB：
   ```bash
   # /usr/share/opensearch/config/jvm.options.d/custom.options
   -Xms512m
   -Xmx512m
   ```

### 验证

```bash
curl http://localhost:9200
# 应返回 OpenSearch 版本信息
```

### 开机自启（APT 安装）

```bash
sudo systemctl enable opensearch
sudo systemctl start opensearch
```

## 第二步：创建 skill 目录

在 OpenClaw workspace 中创建 skill：

```bash
mkdir -p ~/.openclaw/workspace/skills/opensearch-knowledge/scripts
mkdir -p ~/.openclaw/workspace/skills/opensearch-knowledge/references
```

## 第三步：创建脚本文件

需要创建以下 Python 脚本（完整代码见附件 `scripts/` 目录）：

| 文件 | 用途 |
|---|---|
| `opensearch_client.py` | OpenSearch 连接客户端封装 |
| `embedder.py` | Bedrock Titan v2 embedding 封装 |
| `document_parser.py` | 文档解析（md/txt/docx/pdf）+ 分块 |
| `setup_index.py` | 创建 OpenSearch 索引（含 mapping） |
| `ingest.py` | 文档导入（解析 → embedding → 索引） |
| `search.py` | 混合搜索（向量 + BM25） |
| `manage.py` | 索引管理（统计/列表/删除/清空） |
| `requirements.txt` | Python 依赖 |

### 安装 Python 依赖

```bash
cd ~/.openclaw/workspace/skills/opensearch-knowledge/scripts
pip install -r requirements.txt
# 或
pip install --break-system-packages -r requirements.txt
```

requirements.txt 内容：
```
opensearch-py>=2.4.0
python-docx>=0.8.11
PyPDF2>=3.0.0
boto3>=1.28.0
tiktoken>=0.5.0
```

## 第四步：创建 SKILL.md

在 `skills/opensearch-knowledge/SKILL.md` 中编写 skill 说明，告诉 agent 如何使用这些脚本。主要内容：

- 何时使用（搜索公司文档、报告、知识库）
- CLI 命令（setup_index、ingest、search、manage）
- 搜索示例
- 环境变量说明

## 第五步：初始化索引

```bash
cd ~/.openclaw/workspace/skills/opensearch-knowledge

# 创建索引（向量 + 全文搜索）
python3 scripts/setup_index.py --index-name openclaw-knowledge

# 或创建纯文本索引（不需要向量字段）
# 直接用 restore_opensearch.py 恢复 budget-knowledge
```

## 第六步：导入文档

```bash
# 导入单个文件
python3 scripts/ingest.py /path/to/document.md

# 导入整个目录
python3 scripts/ingest.py /path/to/docs/ --tags finance quarterly

# 使用 mock embedding（无 Bedrock 时测试）
python3 scripts/ingest.py /path/to/document.md --mock
```

## 第七步：恢复已有数据

参见 opensearch-export 目录中的 `RESTORE-GUIDE.md`。

## 使用方式

### 搜索

```bash
python3 scripts/search.py "预算超支怎么处理"
python3 scripts/search.py "第三季度营收" --k 5 --debug
```

### 管理

```bash
python3 scripts/manage.py stats          # 查看统计
python3 scripts/manage.py list           # 列出文档
python3 scripts/manage.py delete --file "xxx.md"  # 删除
python3 scripts/manage.py clear          # 清空索引
```

### Agent 调用

Agent 通过 exec 工具调用搜索脚本：

```bash
python3 ~/.openclaw/workspace/skills/opensearch-knowledge/scripts/search.py "查询内容"
```

## 索引 Mapping 说明

### 向量索引（openclaw-knowledge）

```json
{
  "settings": {
    "index.knn": true,
    "analysis": {
      "analyzer": {
        "cjk_analyzer": { "type": "standard", "stopwords": "_cjk_stops_" }
      }
    }
  },
  "mappings": {
    "properties": {
      "content": {
        "type": "text",
        "analyzer": "standard",
        "fields": {
          "cjk": { "type": "text", "analyzer": "cjk_analyzer" }
        }
      },
      "embedding": {
        "type": "knn_vector",
        "dimension": 1024,
        "method": { "name": "hnsw", "engine": "lucene", "space_type": "l2" }
      },
      "filename": { "type": "keyword" },
      "file_type": { "type": "keyword" },
      "chunk_index": { "type": "integer" },
      "created_at": { "type": "date" },
      "tags": { "type": "keyword" }
    }
  }
}
```

### 纯文本索引（budget-knowledge）

budget-knowledge 索引只有文本字段：`title`、`content`、`category`、`file`、`timestamp`，不含向量，使用 BM25 关键词搜索。

## 环境变量

| 变量 | 默认值 | 说明 |
|---|---|---|
| `OPENSEARCH_URL` | http://localhost:9200 | OpenSearch 地址 |
| `OPENSEARCH_USERNAME` | admin | 用户名（安全插件启用时） |
| `OPENSEARCH_PASSWORD` | admin | 密码（安全插件启用时） |
| `DISABLE_SECURITY_PLUGIN` | - | 设为 `true` 跳过认证 |
| `INDEX_NAME` | openclaw-knowledge | 默认索引名 |
| `AWS_REGION` | ap-northeast-1 | Bedrock region（向量搜索用） |

## 资源占用

- **OpenSearch**：最低 512MB heap（`-Xms512m -Xmx512m`），实际占用约 800MB-1.5GB
- **磁盘**：取决于文档量，43 文档约 1MB

## 常见问题

### OpenSearch 启动失败
- 检查 Java 版本（需要 JDK 11+，OpenSearch 自带 bundled JDK）
- 检查内存是否足够（最低 1GB 可用内存）
- 检查端口 9200 是否被占用

### k-NN 搜索不工作
- 确认 `index.knn: true` 已设置
- 确认 k-NN 插件已安装（APT 安装默认包含）
- Docker 安装确认使用的是完整版镜像

### Bedrock 调用失败
- 检查 AWS credentials：`aws sts get-caller-identity`
- 确认 Titan Embed v2 在目标 region 可用
- 确认 IAM 有 `bedrock:InvokeModel` 权限

### 中文搜索效果差
- 确保索引配置了 `cjk_analyzer`
- 搜索时会同时匹配 `content`（standard）和 `content.cjk`（CJK 分词）
